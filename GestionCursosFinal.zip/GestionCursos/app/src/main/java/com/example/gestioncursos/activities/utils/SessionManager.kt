package com.example.gestioncursos.activities.utils

import android.content.Context
import android.content.Intent
import com.example.gestioncursos.activities.login.LoginActivity

object SessionManager {
    private const val PREF = "session"

    fun guardar(context: Context, id: Int, nombre: String, email: String, rol: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putInt("id", id)
            .putString("nombre", nombre)
            .putString("email", email)
            .putString("rol", rol)
            .apply()
    }

    fun id(context: Context): Int =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt("id", -1)

    // ✅ Nueva función
    fun nombre(context: Context): String =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("nombre", "Alumno") ?: "Alumno"

    fun cerrar(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        val i = Intent(context, LoginActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        context.startActivity(i)
    }
}