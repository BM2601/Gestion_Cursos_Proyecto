package com.example.gestioncursos.activities.profesor

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.login.CambiarPasswordActivity
import com.example.gestioncursos.activities.utils.SessionManager
import com.google.android.material.button.MaterialButton

class ConfiguracionProfesorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuracion_profesor)

        findViewById<ImageButton>(R.id.btnBackConfiguracionProfesor).setOnClickListener { finish() }

        findViewById<MaterialButton>(R.id.btnCambiarPasswordProfesor).setOnClickListener {
            startActivity(Intent(this, CambiarPasswordActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnGestionTareasProfesor).setOnClickListener {
            startActivity(Intent(this, GestionTareasProfesorActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnCrearCursoProfesor).setOnClickListener {
            startActivity(Intent(this, CrearEditarCursoActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnCerrarSesionProfesor).setOnClickListener {
            SessionManager.cerrar(this)
        }
    }
}