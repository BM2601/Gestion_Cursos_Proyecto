package com.example.gestioncursos.activities.admin

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.adapters.TareaAdapter
import com.example.gestioncursos.database.DatabaseHelper

class SupervisarTareasAdminActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var rv: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supervisar_tareas_admin)

        db = DatabaseHelper(this)

        rv = findViewById(R.id.rvTareasAdmin)
        rv.layoutManager = LinearLayoutManager(this)

        findViewById<ImageButton>(R.id.btnBackTareas).setOnClickListener {
            finish()
        }

        cargar()
    }

    private fun cargar() {
        rv.adapter = TareaAdapter(
            db.listarTareas(),
            onCompletarClick = { tarea ->
                db.marcarTareaCompletada(tarea.id)
                cargar()
            },
            onEditarClick = {
                // Admin solo supervisa
            },
            onEliminarClick = { tarea ->
                db.eliminarTarea(tarea.id)
                cargar()
            }
        )
    }
}