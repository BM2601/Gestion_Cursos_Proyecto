package com.example.gestioncursos.activities.admin

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.adapters.NotaAdapter
import com.example.gestioncursos.database.DatabaseHelper

class RegistroAcademicosAdminActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_academicos_admin)

        db = DatabaseHelper(this)

        val backId = resources.getIdentifier("btnBackRegistroAcademico", "id", packageName)
        if (backId != 0) {
            findViewById<ImageButton>(backId).setOnClickListener {
                finish()
            }
        }

        val todasLasNotas = db.obtenerTodosUsuarios()
            .filter { it.rol == "alumno" }
            .flatMap { alumno ->
                db.obtenerNotasDelAlumno(alumno.id)
            }

        val recyclerId = resources.getIdentifier("rvRegistroAcademico", "id", packageName)
        if (recyclerId != 0) {
            val rv = findViewById<RecyclerView>(recyclerId)
            rv.layoutManager = LinearLayoutManager(this)
            rv.adapter = NotaAdapter(todasLasNotas)
        }
    }
}