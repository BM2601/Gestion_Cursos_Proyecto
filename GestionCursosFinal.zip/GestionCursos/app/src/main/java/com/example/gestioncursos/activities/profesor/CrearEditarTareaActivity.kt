package com.example.gestioncursos.activities.profesor

import android.content.ContentValues
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.database.DatabaseHelper
import com.example.gestioncursos.models.Curso
import com.example.gestioncursos.models.Tarea

class CrearEditarTareaActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var tareaId = 0
    private var cursos = listOf<Curso>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_editar_tarea)

        db = DatabaseHelper(this)

        val btnBack = findViewById<ImageButton>(R.id.btnBackTarea)
        val tvTituloForm = findViewById<TextView>(R.id.tvTituloTareaForm)
        val edtTitulo = findViewById<EditText>(R.id.edtTituloTarea)
        val edtDescripcion = findViewById<EditText>(R.id.edtDescripcionTarea)
        val spinnerCurso = findViewById<Spinner>(R.id.spinnerCursoTarea)
        val edtFecha = findViewById<EditText>(R.id.edtFechaLimiteTarea)
        val btnGuardar = findViewById<Button>(R.id.btnGuardarTarea)

        btnBack.setOnClickListener {
            finish()
        }

        cargarCursos(spinnerCurso)

        tareaId = intent.getIntExtra("id", 0)

        if (tareaId > 0) {
            tvTituloForm.text = "Editar Tarea"

            edtTitulo.setText(intent.getStringExtra("titulo"))
            edtDescripcion.setText(intent.getStringExtra("descripcion"))
            edtFecha.setText(intent.getStringExtra("fecha"))

            val cursoExtra = intent.getStringExtra("curso") ?: ""
            seleccionarCursoEnSpinner(spinnerCurso, cursoExtra)
        } else {
            tvTituloForm.text = "Registrar Tarea"
        }

        btnGuardar.setOnClickListener {
            val titulo = edtTitulo.text.toString().trim()
            val descripcion = edtDescripcion.text.toString().trim()
            val fecha = edtFecha.text.toString().trim()
            val estado = intent.getStringExtra("estado") ?: "Pendiente"

            if (titulo.isEmpty()) {
                Toast.makeText(this, "Ingresa el título", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (cursos.isEmpty()) {
                Toast.makeText(this, "No hay cursos registrados", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cursoSeleccionado = cursos[spinnerCurso.selectedItemPosition]
            val cursoId = cursoSeleccionado.id.toString()

            if (tareaId == 0) {
                db.insertarTarea(
                    Tarea(
                        id = 0,
                        titulo = titulo,
                        descripcion = descripcion,
                        curso = cursoId,
                        fechaLimite = fecha,
                        estado = "Pendiente"
                    )
                )

                Toast.makeText(this, "Tarea registrada", Toast.LENGTH_SHORT).show()

            } else {
                val values = ContentValues().apply {
                    put(DatabaseHelper.COL_TITULO, titulo)
                    put(DatabaseHelper.COL_DESCRIPCION, descripcion)
                    put(DatabaseHelper.COL_CURSO_ID, cursoId)
                    put(DatabaseHelper.COL_FECHA_LIMITE, fecha)
                    put(DatabaseHelper.COL_ESTADO, estado)
                }

                db.writableDatabase.update(
                    DatabaseHelper.TABLE_TAREAS,
                    values,
                    "${DatabaseHelper.COL_ID}=?",
                    arrayOf(tareaId.toString())
                )

                Toast.makeText(this, "Tarea actualizada", Toast.LENGTH_SHORT).show()
            }

            finish()
        }
    }

    private fun cargarCursos(spinnerCurso: Spinner) {
        cursos = db.obtenerTodosCursos()

        val nombresCursos = if (cursos.isEmpty()) {
            listOf("No hay cursos disponibles")
        } else {
            cursos.map { "${it.id} - ${it.titulo}" }
        }

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            nombresCursos
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCurso.adapter = adapter
    }

    private fun seleccionarCursoEnSpinner(spinnerCurso: Spinner, cursoExtra: String) {
        if (cursos.isEmpty()) return

        val index = cursos.indexOfFirst {
            it.id.toString() == cursoExtra || it.titulo == cursoExtra
        }

        if (index >= 0) {
            spinnerCurso.setSelection(index)
        }
    }
}