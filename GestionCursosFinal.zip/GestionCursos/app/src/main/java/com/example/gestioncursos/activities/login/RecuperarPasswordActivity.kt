package com.example.gestioncursos.activities.login

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton

class RecuperarPasswordActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recuperar_password)

        db = DatabaseHelper(this)

        val etCorreo = findViewById<EditText>(R.id.etCorreoRecuperar)

        findViewById<ImageButton>(R.id.btnBackRecuperar).setOnClickListener { finish() }

        findViewById<MaterialButton>(R.id.btnEnviarRecuperacion).setOnClickListener {
            val correo = etCorreo.text.toString().trim()
            val usuario = db.buscarUsuarioPorEmail(correo)

            if (usuario == null) {
                Toast.makeText(this, "Correo no encontrado", Toast.LENGTH_SHORT).show()
            } else {
                db.cambiarPassword(usuario.id, "123456")
                Toast.makeText(this, "Contraseña cambiada a 123456", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }
}