package com.example.gestioncursos.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.gestioncursos.models.Curso
import com.example.gestioncursos.models.Horario
import com.example.gestioncursos.models.Material
import com.example.gestioncursos.models.Nota
import com.example.gestioncursos.models.Tarea
import com.example.gestioncursos.models.Usuario

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "gestion_cursos.db"
        const val DATABASE_VERSION = 12

        const val TABLE_USUARIOS = "usuarios"
        const val TABLE_CURSOS = "cursos"
        const val TABLE_INSCRIPCIONES = "inscripciones"
        const val TABLE_MATERIALES = "materiales"
        const val TABLE_HORARIOS = "horarios"
        const val TABLE_TAREAS = "tareas"
        const val TABLE_NOTAS = "notas"
        const val TABLE_PAGOS = "pagos"

        const val COL_ID = "id"
        const val COL_NOMBRE = "nombre"
        const val COL_EMAIL = "email"
        const val COL_PASSWORD = "password"
        const val COL_ROL = "rol"
        const val COL_BLOQUEADO = "bloqueado"
        const val COL_CODIGO_ESTUDIANTE = "codigo_estudiante"
        const val COL_TELEFONO = "telefono"

        const val COL_TITULO = "titulo"
        const val COL_DESCRIPCION = "descripcion"
        const val COL_PROFESOR_ID = "profesor_id"
        const val COL_CATEGORIA = "categoria"
        const val COL_ACTIVO = "activo"
        const val COL_IMAGEN_URL = "imagen_url"
        const val COL_DURACION = "duracion"
        const val COL_NIVEL = "nivel"

        const val COL_CURSO_ID = "curso_id"
        const val COL_NOMBRE_ARCHIVO = "nombre_archivo"
        const val COL_RUTA_ARCHIVO = "ruta_archivo"
        const val COL_FECHA_SUBIDA = "fecha_subida"

        const val COL_DIA = "dia"
        const val COL_HORA_INICIO = "hora_inicio"
        const val COL_HORA_FIN = "hora_fin"
        const val COL_AULA = "aula"

        const val COL_FECHA_LIMITE = "fecha_limite"
        const val COL_ESTADO = "estado"

        const val COL_ALUMNO_ID = "alumno_id"
        const val COL_NOTA1 = "nota1"
        const val COL_NOTA2 = "nota2"
        const val COL_NOTA3 = "nota3"
        const val COL_PROMEDIO = "promedio"
        const val COL_COMENTARIO = "comentario"

        const val COL_MONTO = "monto"
        const val COL_CONCEPTO = "concepto"
        const val COL_FECHA_VENCIMIENTO = "fecha_vencimiento"
        const val COL_FECHA_PAGO = "fecha_pago"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE_USUARIOS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NOMBRE TEXT NOT NULL,
                $COL_EMAIL TEXT UNIQUE NOT NULL,
                $COL_PASSWORD TEXT NOT NULL,
                $COL_ROL TEXT NOT NULL,
                $COL_BLOQUEADO INTEGER DEFAULT 0,
                $COL_CODIGO_ESTUDIANTE TEXT,
                $COL_TELEFONO TEXT
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_CURSOS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITULO TEXT NOT NULL,
                $COL_DESCRIPCION TEXT,
                $COL_PROFESOR_ID INTEGER,
                $COL_CATEGORIA TEXT,
                $COL_ACTIVO INTEGER DEFAULT 1,
                $COL_IMAGEN_URL TEXT,
                $COL_DURACION TEXT,
                $COL_NIVEL TEXT,
                FOREIGN KEY($COL_PROFESOR_ID) REFERENCES $TABLE_USUARIOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_INSCRIPCIONES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ALUMNO_ID INTEGER,
                $COL_CURSO_ID INTEGER,
                fecha_inscripcion TEXT,
                FOREIGN KEY($COL_ALUMNO_ID) REFERENCES $TABLE_USUARIOS($COL_ID),
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_MATERIALES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_CURSO_ID INTEGER,
                $COL_NOMBRE_ARCHIVO TEXT,
                $COL_RUTA_ARCHIVO TEXT,
                $COL_FECHA_SUBIDA TEXT,
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_HORARIOS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_CURSO_ID INTEGER,
                $COL_DIA TEXT,
                $COL_HORA_INICIO TEXT,
                $COL_HORA_FIN TEXT,
                $COL_AULA TEXT,
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_TAREAS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITULO TEXT NOT NULL,
                $COL_DESCRIPCION TEXT,
                $COL_CURSO_ID INTEGER,
                $COL_FECHA_LIMITE TEXT,
                $COL_ESTADO TEXT,
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_NOTAS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ALUMNO_ID INTEGER,
                $COL_CURSO_ID INTEGER,
                $COL_NOTA1 REAL,
                $COL_NOTA2 REAL,
                $COL_NOTA3 REAL,
                $COL_PROMEDIO REAL,
                $COL_COMENTARIO TEXT,
                FOREIGN KEY($COL_ALUMNO_ID) REFERENCES $TABLE_USUARIOS($COL_ID),
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_PAGOS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ALUMNO_ID INTEGER NOT NULL,
                $COL_CONCEPTO TEXT NOT NULL,
                $COL_MONTO REAL NOT NULL,
                $COL_FECHA_VENCIMIENTO TEXT NOT NULL,
                $COL_FECHA_PAGO TEXT,
                $COL_ESTADO TEXT DEFAULT 'Pendiente',
                FOREIGN KEY($COL_ALUMNO_ID) REFERENCES $TABLE_USUARIOS($COL_ID)
            )
        """)

        insertarDatosPrueba(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PAGOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NOTAS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_TAREAS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_HORARIOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MATERIALES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_INSCRIPCIONES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CURSOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USUARIOS")
        onCreate(db)
    }

    private fun insertarDatosPrueba(db: SQLiteDatabase) {

        // 1. USUARIOS
        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Admin Principal")
            put(COL_EMAIL, "admin@edu.com")
            put(COL_PASSWORD, "admin123")
            put(COL_ROL, "admin")
            put(COL_BLOQUEADO, 0)
        }) // ID = 1

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Prof. García")
            put(COL_EMAIL, "profesor@edu.com")
            put(COL_PASSWORD, "prof123")
            put(COL_ROL, "profesor")
            put(COL_BLOQUEADO, 0)
        }) // ID = 2

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Juan Alumno")
            put(COL_EMAIL, "alumno@edu.com")
            put(COL_PASSWORD, "alum123")
            put(COL_ROL, "alumno")
            put(COL_BLOQUEADO, 0)
            put(COL_CODIGO_ESTUDIANTE, "EST-2024-001")
            put(COL_TELEFONO, "999111222")
        }) // ID = 3

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Prof. Martínez")
            put(COL_EMAIL, "martinez@edu.com")
            put(COL_PASSWORD, "mart123")
            put(COL_ROL, "profesor")
            put(COL_BLOQUEADO, 0)
            put(COL_TELEFONO, "988111222")
        }) // ID = 4

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Prof. Rodríguez")
            put(COL_EMAIL, "rodriguez@edu.com")
            put(COL_PASSWORD, "rod123")
            put(COL_ROL, "profesor")
            put(COL_BLOQUEADO, 0)
            put(COL_TELEFONO, "977111222")
        }) // ID = 5

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "María López")
            put(COL_EMAIL, "maria@edu.com")
            put(COL_PASSWORD, "maria123")
            put(COL_ROL, "alumno")
            put(COL_BLOQUEADO, 0)
            put(COL_CODIGO_ESTUDIANTE, "EST-2024-002")
            put(COL_TELEFONO, "999222333")
        }) // ID = 6

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Carlos Pérez")
            put(COL_EMAIL, "carlos@edu.com")
            put(COL_PASSWORD, "carlos123")
            put(COL_ROL, "alumno")
            put(COL_BLOQUEADO, 0)
            put(COL_CODIGO_ESTUDIANTE, "EST-2024-003")
            put(COL_TELEFONO, "999333444")
        }) // ID = 7

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Ana Torres")
            put(COL_EMAIL, "ana@edu.com")
            put(COL_PASSWORD, "ana123")
            put(COL_ROL, "alumno")
            put(COL_BLOQUEADO, 0)
            put(COL_CODIGO_ESTUDIANTE, "EST-2024-004")
            put(COL_TELEFONO, "999444555")
        }) // ID = 8

        db.insert(TABLE_USUARIOS, null, ContentValues().apply {
            put(COL_NOMBRE, "Luis Ramos")
            put(COL_EMAIL, "luis@edu.com")
            put(COL_PASSWORD, "luis123")
            put(COL_ROL, "alumno")
            put(COL_BLOQUEADO, 0)
            put(COL_CODIGO_ESTUDIANTE, "EST-2024-005")
            put(COL_TELEFONO, "999555666")
        }) // ID = 9

        // 2. CURSOS (deben ir ANTES que inscripciones/notas/tareas)
        db.insert(TABLE_CURSOS, null, ContentValues().apply {
            put(COL_TITULO, "Kotlin Avanzado")
            put(COL_DESCRIPCION, "Aprende Kotlin desde cero hasta experto")
            put(COL_PROFESOR_ID, 2)
            put(COL_CATEGORIA, "Programación")
            put(COL_ACTIVO, 1)
            put(COL_DURACION, "40 horas")
            put(COL_NIVEL, "Avanzado")
        }) // ID = 1

        db.insert(TABLE_CURSOS, null, ContentValues().apply {
            put(COL_TITULO, "Diseño UI/UX")
            put(COL_DESCRIPCION, "Fundamentos del diseño de interfaces")
            put(COL_PROFESOR_ID, 2)
            put(COL_CATEGORIA, "Diseño")
            put(COL_ACTIVO, 1)
            put(COL_DURACION, "25 horas")
            put(COL_NIVEL, "Intermedio")
        }) // ID = 2

        db.insert(TABLE_CURSOS, null, ContentValues().apply {
            put(COL_TITULO, "Base de Datos SQL")
            put(COL_DESCRIPCION, "Manejo completo de bases de datos")
            put(COL_PROFESOR_ID, 2)
            put(COL_CATEGORIA, "Datos")
            put(COL_ACTIVO, 0)
            put(COL_DURACION, "30 horas")
            put(COL_NIVEL, "Básico")
        }) // ID = 3

        // 3. HORARIOS
        db.insert(TABLE_HORARIOS, null, ContentValues().apply {
            put(COL_CURSO_ID, 1)
            put(COL_DIA, "Lunes")
            put(COL_HORA_INICIO, "08:00")
            put(COL_HORA_FIN, "10:00")
            put(COL_AULA, "Aula 101")
        })
        db.insert(TABLE_HORARIOS, null, ContentValues().apply {
            put(COL_CURSO_ID, 1)
            put(COL_DIA, "Miércoles")
            put(COL_HORA_INICIO, "10:00")
            put(COL_HORA_FIN, "12:00")
            put(COL_AULA, "Lab 2")
        })
        db.insert(TABLE_HORARIOS, null, ContentValues().apply {
            put(COL_CURSO_ID, 2)
            put(COL_DIA, "Viernes")
            put(COL_HORA_INICIO, "14:00")
            put(COL_HORA_FIN, "16:00")
            put(COL_AULA, "Aula 203")
        })

        // 4. INSCRIPCIONES
        db.insert(TABLE_INSCRIPCIONES, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CURSO_ID, 1)
            put("fecha_inscripcion", "2024-01-15")
        })
        db.insert(TABLE_INSCRIPCIONES, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CURSO_ID, 2)
            put("fecha_inscripcion", "2024-02-01")
        })
        db.insert(TABLE_INSCRIPCIONES, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CURSO_ID, 3)
            put("fecha_inscripcion", "2024-03-10")
        })
        db.insert(TABLE_INSCRIPCIONES, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 6)
            put(COL_CURSO_ID, 1)
            put("fecha_inscripcion", "2024-04-01")
        })
        db.insert(TABLE_INSCRIPCIONES, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 7)
            put(COL_CURSO_ID, 2)
            put("fecha_inscripcion", "2024-04-02")
        })
        db.insert(TABLE_INSCRIPCIONES, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 8)
            put(COL_CURSO_ID, 1)
            put("fecha_inscripcion", "2024-04-03")
        })
        db.insert(TABLE_INSCRIPCIONES, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 9)
            put(COL_CURSO_ID, 3)
            put("fecha_inscripcion", "2024-04-04")
        })

        // 5. TAREAS
        db.insert(TABLE_TAREAS, null, ContentValues().apply {
            put(COL_TITULO, "Proyecto Final Kotlin")
            put(COL_DESCRIPCION, "Crear una aplicación Android completa")
            put(COL_CURSO_ID, 1)
            put(COL_FECHA_LIMITE, "2026-12-15")
            put(COL_ESTADO, "Pendiente")
        })
        db.insert(TABLE_TAREAS, null, ContentValues().apply {
            put(COL_TITULO, "Wireframe Aplicación")
            put(COL_DESCRIPCION, "Diseñar pantallas principales")
            put(COL_CURSO_ID, 2)
            put(COL_FECHA_LIMITE, "2026-11-30")
            put(COL_ESTADO, "Pendiente")
        })
        db.insert(TABLE_TAREAS, null, ContentValues().apply {
            put(COL_TITULO, "Consultas SQL")
            put(COL_DESCRIPCION, "Resolver ejercicios de consultas")
            put(COL_CURSO_ID, 3)
            put(COL_FECHA_LIMITE, "2026-10-20")
            put(COL_ESTADO, "Completada")
        })

        // 6. NOTAS
        db.insert(TABLE_NOTAS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CURSO_ID, 1)
            put(COL_NOTA1, 17.0)
            put(COL_NOTA2, 18.0)
            put(COL_NOTA3, 17.5)
            put(COL_PROMEDIO, (17.0 + 18.0 + 17.5) / 3)
            put(COL_COMENTARIO, "Excelente desempeño")
        })
        db.insert(TABLE_NOTAS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CURSO_ID, 2)
            put(COL_NOTA1, 18.0)
            put(COL_NOTA2, 18.0)
            put(COL_NOTA3, 18.0)
            put(COL_PROMEDIO, 18.0)
            put(COL_COMENTARIO, "Muy buen trabajo")
        })
        db.insert(TABLE_NOTAS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CURSO_ID, 3)
            put(COL_NOTA1, 15.0)
            put(COL_NOTA2, 16.0)
            put(COL_NOTA3, 15.5)
            put(COL_PROMEDIO, (15.0 + 16.0 + 15.5) / 3)
            put(COL_COMENTARIO, "Puede mejorar")
        })
        db.insert(TABLE_NOTAS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 6)
            put(COL_CURSO_ID, 1)
            put(COL_NOTA1, 19.0)
            put(COL_NOTA2, 18.5)
            put(COL_NOTA3, 20.0)
            put(COL_PROMEDIO, (19.0 + 18.5 + 20.0) / 3)
            put(COL_COMENTARIO, "Participación destacada")
        })
        db.insert(TABLE_NOTAS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 7)
            put(COL_CURSO_ID, 2)
            put(COL_NOTA1, 14.0)
            put(COL_NOTA2, 15.0)
            put(COL_NOTA3, 16.0)
            put(COL_PROMEDIO, (14.0 + 15.0 + 16.0) / 3)
            put(COL_COMENTARIO, "Debe practicar más")
        })
        db.insert(TABLE_NOTAS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 8)
            put(COL_CURSO_ID, 1)
            put(COL_NOTA1, 16.0)
            put(COL_NOTA2, 17.0)
            put(COL_NOTA3, 18.0)
            put(COL_PROMEDIO, (16.0 + 17.0 + 18.0) / 3)
            put(COL_COMENTARIO, "Buen avance")
        })
        db.insert(TABLE_NOTAS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 9)
            put(COL_CURSO_ID, 3)
            put(COL_NOTA1, 13.0)
            put(COL_NOTA2, 14.5)
            put(COL_NOTA3, 15.0)
            put(COL_PROMEDIO, (13.0 + 14.5 + 15.0) / 3)
            put(COL_COMENTARIO, "Necesita reforzar consultas")
        })

        // 7. PAGOS
        db.insert(TABLE_PAGOS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CONCEPTO, "Matrícula")
            put(COL_MONTO, 250.0)
            put(COL_FECHA_VENCIMIENTO, "2026-08-01")
            put(COL_FECHA_PAGO, "2026-07-28")
            put(COL_ESTADO, "Pagado")
        })
        db.insert(TABLE_PAGOS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CONCEPTO, "Mensualidad Agosto")
            put(COL_MONTO, 120.0)
            put(COL_FECHA_VENCIMIENTO, "2026-08-15")
            put(COL_ESTADO, "Pendiente")
        })
        db.insert(TABLE_PAGOS, null, ContentValues().apply {
            put(COL_ALUMNO_ID, 3)
            put(COL_CONCEPTO, "Mensualidad")
            put(COL_MONTO, 120.0)
            put(COL_FECHA_VENCIMIENTO, "2026-07-01")
            put(COL_ESTADO, "Pendiente")
        })

        // 8. MATERIALES
        db.insert(TABLE_MATERIALES, null, ContentValues().apply {
            put(COL_CURSO_ID, 1)
            put(COL_NOMBRE_ARCHIVO, "Guia Kotlin.pdf")
            put(COL_RUTA_ARCHIVO, "/materiales/kotlin.pdf")
            put(COL_FECHA_SUBIDA, "2026-01-10")
        })
        db.insert(TABLE_MATERIALES, null, ContentValues().apply {
            put(COL_CURSO_ID, 2)
            put(COL_NOMBRE_ARCHIVO, "Manual UX.pdf")
            put(COL_RUTA_ARCHIVO, "/materiales/uiux.pdf")
            put(COL_FECHA_SUBIDA, "2026-01-15")
        })
    }

    fun login(email: String, password: String): Usuario? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_EMAIL=? AND $COL_PASSWORD=?",
            arrayOf(email, password)
        )

        var usuario: Usuario? = null
        if (cursor.moveToFirst()) usuario = cursorToUsuario(cursor)
        cursor.close()
        return usuario
    }

    fun registrarUsuario(
        nombre: String,
        email: String,
        password: String,
        rol: String,
        codigoEstudiante: String,
        telefono: String
    ): Long {
        val values = ContentValues().apply {
            put(COL_NOMBRE, nombre)
            put(COL_EMAIL, email)
            put(COL_PASSWORD, password)
            put(COL_ROL, rol)
            put(COL_BLOQUEADO, 0)
            put(COL_CODIGO_ESTUDIANTE, codigoEstudiante)
            put(COL_TELEFONO, telefono)
        }

        return writableDatabase.insert(TABLE_USUARIOS, null, values)
    }

    fun cambiarPassword(usuarioId: Int, nuevaPassword: String): Int {
        val values = ContentValues().apply {
            put(COL_PASSWORD, nuevaPassword)
        }

        return writableDatabase.update(
            TABLE_USUARIOS,
            values,
            "$COL_ID=?",
            arrayOf(usuarioId.toString())
        )
    }

    fun buscarUsuarioPorEmail(email: String): Usuario? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_EMAIL=?",
            arrayOf(email)
        )

        var usuario: Usuario? = null
        if (cursor.moveToFirst()) usuario = cursorToUsuario(cursor)
        cursor.close()
        return usuario
    }

    fun obtenerTodosUsuarios(): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS ORDER BY $COL_ROL, $COL_NOMBRE",
            null
        )

        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()
        return lista
    }

    fun obtenerProfesores(): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_ROL='profesor'",
            null
        )

        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()
        return lista
    }

    fun obtenerTareasAlumno(alumnoId: Int): ArrayList<Tarea> {
        val lista = ArrayList<Tarea>()

        val query = """
        SELECT t.*, c.$COL_TITULO AS nombre_curso
        FROM $TABLE_TAREAS t
        INNER JOIN $TABLE_CURSOS c ON t.$COL_CURSO_ID = c.$COL_ID
        INNER JOIN $TABLE_INSCRIPCIONES i ON c.$COL_ID = i.$COL_CURSO_ID
        WHERE i.$COL_ALUMNO_ID = ?
        ORDER BY t.$COL_FECHA_LIMITE
    """

        val cursor = readableDatabase.rawQuery(query, arrayOf(alumnoId.toString()))

        while (cursor.moveToNext()) {
            lista.add(
                Tarea(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                    titulo = cursor.getString(cursor.getColumnIndexOrThrow(COL_TITULO)),
                    descripcion = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPCION)) ?: "",
                    curso = cursor.getString(cursor.getColumnIndexOrThrow("nombre_curso")) ?: "",
                    fechaLimite = cursor.getString(cursor.getColumnIndexOrThrow(COL_FECHA_LIMITE)) ?: "",
                    estado = cursor.getString(cursor.getColumnIndexOrThrow(COL_ESTADO)) ?: "Pendiente"
                )
            )
        }

        cursor.close()
        return lista
    }

    fun obtenerAlumnos(): ArrayList<Usuario> {
        val lista = ArrayList<Usuario>()

        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_ROL='alumno'",
            null
        )

        while (cursor.moveToNext()) {
            lista.add(
                Usuario(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                    nombre = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOMBRE)),
                    email = cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL)),
                    rol = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROL)),
                    password = ""
                )
            )
        }

        cursor.close()
        return lista
    }

    fun insertarUsuario(usuario: Usuario): Long {
        val values = ContentValues().apply {
            put(COL_NOMBRE, usuario.nombre)
            put(COL_EMAIL, usuario.email)
            put(COL_PASSWORD, usuario.password)
            put(COL_ROL, usuario.rol)
            put(COL_BLOQUEADO, if (usuario.bloqueado) 1 else 0)
            put(COL_CODIGO_ESTUDIANTE, usuario.codigoEstudiante)
            put(COL_TELEFONO, usuario.telefono)
        }

        return writableDatabase.insert(TABLE_USUARIOS, null, values)
    }

    fun actualizarUsuario(usuario: Usuario): Int {
        val values = ContentValues().apply {
            put(COL_NOMBRE, usuario.nombre)
            put(COL_EMAIL, usuario.email)
            put(COL_ROL, usuario.rol)
            put(COL_CODIGO_ESTUDIANTE, usuario.codigoEstudiante)
            put(COL_TELEFONO, usuario.telefono)
            if (usuario.password.isNotEmpty()) put(COL_PASSWORD, usuario.password)
        }

        return writableDatabase.update(
            TABLE_USUARIOS,
            values,
            "$COL_ID=?",
            arrayOf(usuario.id.toString())
        )
    }

    fun eliminarUsuario(usuarioId: Int): Int {
        val db = writableDatabase

        db.delete(TABLE_NOTAS, "$COL_ALUMNO_ID=?", arrayOf(usuarioId.toString()))
        db.delete(TABLE_INSCRIPCIONES, "$COL_ALUMNO_ID=?", arrayOf(usuarioId.toString()))
        db.delete(TABLE_PAGOS, "$COL_ALUMNO_ID=?", arrayOf(usuarioId.toString()))

        return db.delete(TABLE_USUARIOS, "$COL_ID=?", arrayOf(usuarioId.toString()))
    }

    fun toggleBloqueoUsuario(usuarioId: Int, bloqueado: Boolean): Int {
        val values = ContentValues().apply {
            put(COL_BLOQUEADO, if (bloqueado) 1 else 0)
        }

        return writableDatabase.update(
            TABLE_USUARIOS,
            values,
            "$COL_ID=?",
            arrayOf(usuarioId.toString())
        )
    }

    fun cambiarRolUsuario(usuarioId: Int, nuevoRol: String): Int {
        val values = ContentValues().apply {
            put(COL_ROL, nuevoRol)
        }

        return writableDatabase.update(
            TABLE_USUARIOS,
            values,
            "$COL_ID=?",
            arrayOf(usuarioId.toString())
        )
    }

    fun obtenerUsuarioPorId(usuarioId: Int): Usuario? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_ID=?",
            arrayOf(usuarioId.toString())
        )

        var usuario: Usuario? = null
        if (cursor.moveToFirst()) usuario = cursorToUsuario(cursor)
        cursor.close()
        return usuario
    }

    fun buscarUsuarios(query: String): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val param = "%$query%"

        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_NOMBRE LIKE ? OR $COL_EMAIL LIKE ?",
            arrayOf(param, param)
        )

        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()
        return lista
    }

    fun actualizarPerfilAlumno(usuarioId: Int, nombre: String, telefono: String): Int {
        val values = ContentValues().apply {
            put(COL_NOMBRE, nombre)
            put(COL_TELEFONO, telefono)
        }

        return writableDatabase.update(
            TABLE_USUARIOS,
            values,
            "$COL_ID=?",
            arrayOf(usuarioId.toString())
        )
    }

    fun obtenerTodosCursos(): List<Curso> {
        val lista = mutableListOf<Curso>()

        val query = """
            SELECT c.*, u.$COL_NOMBRE AS nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            ORDER BY c.$COL_TITULO
        """

        val cursor = readableDatabase.rawQuery(query, null)
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()

        return lista
    }

    fun obtenerCursosActivos(): List<Curso> {
        val lista = mutableListOf<Curso>()

        val query = """
            SELECT c.*, u.$COL_NOMBRE AS nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            WHERE c.$COL_ACTIVO = 1
            ORDER BY c.$COL_TITULO
        """

        val cursor = readableDatabase.rawQuery(query, null)
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()

        return lista
    }

    fun obtenerCursosDelProfesor(profesorId: Int): List<Curso> {
        val lista = mutableListOf<Curso>()

        val query = """
            SELECT c.*, u.$COL_NOMBRE AS nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            WHERE c.$COL_PROFESOR_ID = ?
            ORDER BY c.$COL_TITULO
        """

        val cursor = readableDatabase.rawQuery(query, arrayOf(profesorId.toString()))
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()

        return lista
    }

    fun obtenerCursosDelAlumno(alumnoId: Int): List<Curso> {
        val lista = mutableListOf<Curso>()

        val query = """
            SELECT c.*, u.$COL_NOMBRE AS nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            INNER JOIN $TABLE_INSCRIPCIONES i ON c.$COL_ID = i.$COL_CURSO_ID
            WHERE i.$COL_ALUMNO_ID = ?
            ORDER BY c.$COL_TITULO
        """

        val cursor = readableDatabase.rawQuery(query, arrayOf(alumnoId.toString()))
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()

        return lista
    }

    fun buscarCursos(query: String): List<Curso> {
        val lista = mutableListOf<Curso>()
        val param = "%$query%"

        val sql = """
            SELECT c.*, u.$COL_NOMBRE AS nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            WHERE c.$COL_ACTIVO = 1
            AND (
                c.$COL_TITULO LIKE ?
                OR c.$COL_DESCRIPCION LIKE ?
                OR c.$COL_CATEGORIA LIKE ?
            )
            ORDER BY c.$COL_TITULO
        """

        val cursor = readableDatabase.rawQuery(sql, arrayOf(param, param, param))
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()

        return lista
    }

    fun insertarCurso(curso: Curso): Long {
        val values = ContentValues().apply {
            put(COL_TITULO, curso.titulo)
            put(COL_DESCRIPCION, curso.descripcion)
            put(COL_PROFESOR_ID, curso.profesorId)
            put(COL_CATEGORIA, curso.categoria)
            put(COL_ACTIVO, if (curso.activo) 1 else 0)
            put(COL_DURACION, curso.duracion)
            put(COL_NIVEL, curso.nivel)
        }

        return writableDatabase.insert(TABLE_CURSOS, null, values)
    }

    fun actualizarCurso(curso: Curso): Int {
        val values = ContentValues().apply {
            put(COL_TITULO, curso.titulo)
            put(COL_DESCRIPCION, curso.descripcion)
            put(COL_PROFESOR_ID, curso.profesorId)
            put(COL_CATEGORIA, curso.categoria)
            put(COL_ACTIVO, if (curso.activo) 1 else 0)
            put(COL_DURACION, curso.duracion)
            put(COL_NIVEL, curso.nivel)
        }

        return writableDatabase.update(
            TABLE_CURSOS,
            values,
            "$COL_ID=?",
            arrayOf(curso.id.toString())
        )
    }

    fun eliminarCurso(cursoId: Int): Int {
        val db = writableDatabase

        db.delete(TABLE_INSCRIPCIONES, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_MATERIALES, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_HORARIOS, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_TAREAS, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_NOTAS, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))

        return db.delete(TABLE_CURSOS, "$COL_ID=?", arrayOf(cursoId.toString()))
    }

    fun toggleEstadoCurso(cursoId: Int, activo: Boolean): Int {
        val values = ContentValues().apply {
            put(COL_ACTIVO, if (activo) 1 else 0)
        }

        return writableDatabase.update(
            TABLE_CURSOS,
            values,
            "$COL_ID=?",
            arrayOf(cursoId.toString())
        )
    }

    fun asignarProfesor(cursoId: Int, profesorId: Int): Int {
        val values = ContentValues().apply {
            put(COL_PROFESOR_ID, profesorId)
        }

        return writableDatabase.update(
            TABLE_CURSOS,
            values,
            "$COL_ID=?",
            arrayOf(cursoId.toString())
        )
    }

    fun asignarProfesorCurso(cursoId: Int, profesorId: Int): Int {
        return asignarProfesor(cursoId, profesorId)
    }

    fun inscribirAlumno(alumnoId: Int, cursoId: Int): Long {
        if (estaInscrito(alumnoId, cursoId)) return -1

        val fecha = java.text.SimpleDateFormat(
            "yyyy-MM-dd",
            java.util.Locale.getDefault()
        ).format(java.util.Date())

        val values = ContentValues().apply {
            put(COL_ALUMNO_ID, alumnoId)
            put(COL_CURSO_ID, cursoId)
            put("fecha_inscripcion", fecha)
        }

        return writableDatabase.insert(TABLE_INSCRIPCIONES, null, values)
    }

    fun estaInscrito(alumnoId: Int, cursoId: Int): Boolean {
        val cursor = readableDatabase.rawQuery(
            "SELECT $COL_ID FROM $TABLE_INSCRIPCIONES WHERE $COL_ALUMNO_ID=? AND $COL_CURSO_ID=?",
            arrayOf(alumnoId.toString(), cursoId.toString())
        )

        val existe = cursor.moveToFirst()
        cursor.close()
        return existe
    }

    fun obtenerAlumnosDelCurso(cursoId: Int): List<Usuario> {
        val lista = mutableListOf<Usuario>()

        val query = """
            SELECT u.*
            FROM $TABLE_USUARIOS u
            INNER JOIN $TABLE_INSCRIPCIONES i ON u.$COL_ID = i.$COL_ALUMNO_ID
            WHERE i.$COL_CURSO_ID = ?
            ORDER BY u.$COL_NOMBRE
        """

        val cursor = readableDatabase.rawQuery(query, arrayOf(cursoId.toString()))
        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()

        return lista
    }

    fun insertarTarea(tarea: Tarea): Long {
        val values = ContentValues().apply {
            put(COL_TITULO, tarea.titulo)
            put(COL_DESCRIPCION, tarea.descripcion)
            put(COL_CURSO_ID, tarea.curso)
            put(COL_FECHA_LIMITE, tarea.fechaLimite)
            put(COL_ESTADO, tarea.estado)
        }

        return writableDatabase.insert(TABLE_TAREAS, null, values)
    }

    fun listarTareas(): ArrayList<Tarea> {
        val lista = ArrayList<Tarea>()

        val query = """
            SELECT t.*, c.$COL_TITULO AS nombre_curso
            FROM $TABLE_TAREAS t
            LEFT JOIN $TABLE_CURSOS c ON t.$COL_CURSO_ID = c.$COL_ID
            ORDER BY t.$COL_FECHA_LIMITE
        """

        val cursor = readableDatabase.rawQuery(query, null)

        while (cursor.moveToNext()) {
            lista.add(
                Tarea(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                    titulo = cursor.getString(cursor.getColumnIndexOrThrow(COL_TITULO)),
                    descripcion = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPCION)) ?: "",
                    curso = cursor.getString(cursor.getColumnIndexOrThrow("nombre_curso")) ?: "",
                    fechaLimite = cursor.getString(cursor.getColumnIndexOrThrow(COL_FECHA_LIMITE)) ?: "",
                    estado = cursor.getString(cursor.getColumnIndexOrThrow(COL_ESTADO)) ?: "Pendiente"
                )
            )
        }

        cursor.close()
        return lista
    }

    fun marcarTareaCompletada(id: Int): Int {
        val values = ContentValues().apply {
            put(COL_ESTADO, "Completada")
        }

        return writableDatabase.update(
            TABLE_TAREAS,
            values,
            "$COL_ID=?",
            arrayOf(id.toString())
        )
    }

    fun eliminarTarea(id: Int): Int {
        return writableDatabase.delete(
            TABLE_TAREAS,
            "$COL_ID=?",
            arrayOf(id.toString())
        )
    }

    fun asignarNota(
        alumnoId: Int,
        cursoId: Int,
        nota1: Double,
        nota2: Double,
        nota3: Double,
        promedio: Double,
        comentario: String
    ): Long {
        val cursor = readableDatabase.rawQuery(
            "SELECT $COL_ID FROM $TABLE_NOTAS WHERE $COL_ALUMNO_ID=? AND $COL_CURSO_ID=?",
            arrayOf(alumnoId.toString(), cursoId.toString())
        )

        val existe = cursor.moveToFirst()
        val notaId = if (existe) cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)) else -1
        cursor.close()

        val values = ContentValues().apply {
            put(COL_ALUMNO_ID, alumnoId)
            put(COL_CURSO_ID, cursoId)
            put(COL_NOTA1, nota1)
            put(COL_NOTA2, nota2)
            put(COL_NOTA3, nota3)
            put(COL_PROMEDIO, promedio)
            put(COL_COMENTARIO, comentario)
        }

        return if (existe) {
            writableDatabase.update(
                TABLE_NOTAS,
                values,
                "$COL_ID=?",
                arrayOf(notaId.toString())
            ).toLong()
        } else {
            writableDatabase.insert(TABLE_NOTAS, null, values)
        }
    }

    fun obtenerNotasDelAlumno(alumnoId: Int): List<Nota> {
        val lista = mutableListOf<Nota>()

        val query = """
            SELECT n.*, c.$COL_TITULO AS titulo_curso
            FROM $TABLE_NOTAS n
            INNER JOIN $TABLE_CURSOS c ON n.$COL_CURSO_ID = c.$COL_ID
            WHERE n.$COL_ALUMNO_ID = ?
        """

        val cursor = readableDatabase.rawQuery(query, arrayOf(alumnoId.toString()))

        while (cursor.moveToNext()) {
            lista.add(cursorToNota(cursor))
        }

        cursor.close()
        return lista
    }

    fun obtenerNotaDeAlumnoEnCurso(alumnoId: Int, cursoId: Int): Nota? {
        val query = """
            SELECT n.*, c.$COL_TITULO AS titulo_curso
            FROM $TABLE_NOTAS n
            INNER JOIN $TABLE_CURSOS c ON n.$COL_CURSO_ID = c.$COL_ID
            WHERE n.$COL_ALUMNO_ID = ? AND n.$COL_CURSO_ID = ?
        """

        val cursor = readableDatabase.rawQuery(
            query,
            arrayOf(alumnoId.toString(), cursoId.toString())
        )

        var nota: Nota? = null
        if (cursor.moveToFirst()) nota = cursorToNota(cursor)
        cursor.close()

        return nota
    }

    fun calcularPromedioAlumno(alumnoId: Int): Double {
        val cursor = readableDatabase.rawQuery(
            "SELECT AVG($COL_PROMEDIO) FROM $TABLE_NOTAS WHERE $COL_ALUMNO_ID=?",
            arrayOf(alumnoId.toString())
        )

        var promedio = 0.0
        if (cursor.moveToFirst()) promedio = cursor.getDouble(0)
        cursor.close()
        return promedio
    }

    fun registrarPago(
        alumnoId: Int,
        concepto: String,
        monto: Double,
        fechaVencimiento: String
    ): Long {
        val values = ContentValues().apply {
            put(COL_ALUMNO_ID, alumnoId)
            put(COL_CONCEPTO, concepto)
            put(COL_MONTO, monto)
            put(COL_FECHA_VENCIMIENTO, fechaVencimiento)
            put(COL_ESTADO, "Pendiente")
        }

        return writableDatabase.insert(TABLE_PAGOS, null, values)
    }

    fun marcarPagoComoPagado(idPago: Int): Int {
        val fecha = java.text.SimpleDateFormat(
            "yyyy-MM-dd",
            java.util.Locale.getDefault()
        ).format(java.util.Date())

        val values = ContentValues().apply {
            put(COL_ESTADO, "Pagado")
            put(COL_FECHA_PAGO, fecha)
        }

        return writableDatabase.update(
            TABLE_PAGOS,
            values,
            "$COL_ID=?",
            arrayOf(idPago.toString())
        )
    }

    fun obtenerPagosPendientes(alumnoId: Int): Int {
        val cursor = readableDatabase.rawQuery(
            """
            SELECT COUNT(*)
            FROM $TABLE_PAGOS
            WHERE $COL_ALUMNO_ID=?
            AND $COL_ESTADO='Pendiente'
            """,
            arrayOf(alumnoId.toString())
        )

        var cantidad = 0
        if (cursor.moveToFirst()) cantidad = cursor.getInt(0)
        cursor.close()

        return cantidad
    }

    fun insertarMaterial(material: Material): Long {
        val values = ContentValues().apply {
            put(COL_CURSO_ID, material.cursoId)
            put(COL_NOMBRE_ARCHIVO, material.nombreArchivo)
            put(COL_RUTA_ARCHIVO, material.rutaArchivo)
            put(COL_FECHA_SUBIDA, material.fechaSubida)
        }

        return writableDatabase.insert(TABLE_MATERIALES, null, values)
    }

    fun obtenerMaterialesDeCurso(cursoId: Int): List<Material> {
        val lista = mutableListOf<Material>()

        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_MATERIALES WHERE $COL_CURSO_ID=?",
            arrayOf(cursoId.toString())
        )

        while (cursor.moveToNext()) {
            lista.add(
                Material(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                    cursoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CURSO_ID)),
                    nombreArchivo = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOMBRE_ARCHIVO)),
                    rutaArchivo = cursor.getString(cursor.getColumnIndexOrThrow(COL_RUTA_ARCHIVO)),
                    fechaSubida = cursor.getString(cursor.getColumnIndexOrThrow(COL_FECHA_SUBIDA))
                )
            )
        }

        cursor.close()
        return lista
    }

    fun eliminarMaterial(materialId: Int): Int {
        return writableDatabase.delete(
            TABLE_MATERIALES,
            "$COL_ID=?",
            arrayOf(materialId.toString())
        )
    }

    fun insertarHorario(horario: Horario): Long {
        val values = ContentValues().apply {
            put(COL_CURSO_ID, horario.cursoId)
            put(COL_DIA, horario.dia)
            put(COL_HORA_INICIO, horario.horaInicio)
            put(COL_HORA_FIN, horario.horaFin)
            put(COL_AULA, horario.aula)
        }

        return writableDatabase.insert(TABLE_HORARIOS, null, values)
    }

    fun obtenerHorarios(): List<Horario> {
        val lista = mutableListOf<Horario>()

        val query = """
            SELECT h.*, c.$COL_TITULO AS nombre_curso
            FROM $TABLE_HORARIOS h
            INNER JOIN $TABLE_CURSOS c ON h.$COL_CURSO_ID = c.$COL_ID
        """

        val cursor = readableDatabase.rawQuery(query, null)

        while (cursor.moveToNext()) lista.add(cursorToHorario(cursor))
        cursor.close()

        return lista
    }

    fun obtenerHorariosProfesor(profesorId: Int): List<Horario> {
        val lista = mutableListOf<Horario>()

        val query = """
            SELECT h.*, c.$COL_TITULO AS nombre_curso
            FROM $TABLE_HORARIOS h
            INNER JOIN $TABLE_CURSOS c ON h.$COL_CURSO_ID = c.$COL_ID
            WHERE c.$COL_PROFESOR_ID = ?
        """

        val cursor = readableDatabase.rawQuery(query, arrayOf(profesorId.toString()))

        while (cursor.moveToNext()) lista.add(cursorToHorario(cursor))
        cursor.close()

        return lista
    }

    fun obtenerHorariosAlumno(alumnoId: Int): List<Horario> {
        val lista = mutableListOf<Horario>()

        val query = """
            SELECT h.*, c.$COL_TITULO AS nombre_curso
            FROM $TABLE_HORARIOS h
            INNER JOIN $TABLE_CURSOS c ON h.$COL_CURSO_ID = c.$COL_ID
            INNER JOIN $TABLE_INSCRIPCIONES i ON c.$COL_ID = i.$COL_CURSO_ID
            WHERE i.$COL_ALUMNO_ID = ?
        """

        val cursor = readableDatabase.rawQuery(query, arrayOf(alumnoId.toString()))

        while (cursor.moveToNext()) lista.add(cursorToHorario(cursor))
        cursor.close()

        return lista
    }

    fun obtenerProximaClase(alumnoId: Int): Horario? {
        val horarios = obtenerHorariosAlumno(alumnoId)
        if (horarios.isEmpty()) return null

        val diasSemana = listOf(
            "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"
        )

        val calendario = java.util.Calendar.getInstance()
        val diaActual = calendario.get(java.util.Calendar.DAY_OF_WEEK)

        val indiceActual = when (diaActual) {
            java.util.Calendar.MONDAY -> 0
            java.util.Calendar.TUESDAY -> 1
            java.util.Calendar.WEDNESDAY -> 2
            java.util.Calendar.THURSDAY -> 3
            java.util.Calendar.FRIDAY -> 4
            java.util.Calendar.SATURDAY -> 5
            else -> 6
        }

        return horarios.minByOrNull { horario ->
            val indiceHorario = diasSemana.indexOf(horario.dia)
            if (indiceHorario >= indiceActual) {
                indiceHorario - indiceActual
            } else {
                7 - (indiceActual - indiceHorario)
            }
        }
    }

    private fun cursorToUsuario(cursor: Cursor): Usuario {
        return Usuario(
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
            nombre = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOMBRE)),
            email = cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL)),
            rol = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROL)),
            password = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD)),
            bloqueado = cursor.getInt(cursor.getColumnIndexOrThrow(COL_BLOQUEADO)) == 1,
            codigoEstudiante = try {
                cursor.getString(cursor.getColumnIndexOrThrow(COL_CODIGO_ESTUDIANTE)) ?: ""
            } catch (e: Exception) {
                ""
            },
            telefono = try {
                cursor.getString(cursor.getColumnIndexOrThrow(COL_TELEFONO)) ?: ""
            } catch (e: Exception) {
                ""
            }
        )
    }

    private fun cursorToCurso(cursor: Cursor): Curso {
        return Curso(
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
            titulo = cursor.getString(cursor.getColumnIndexOrThrow(COL_TITULO)),
            descripcion = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPCION)) ?: "",
            profesorId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_PROFESOR_ID)),
            nombreProfesor = try {
                cursor.getString(cursor.getColumnIndexOrThrow("nombre_profesor")) ?: ""
            } catch (e: Exception) {
                ""
            },
            categoria = cursor.getString(cursor.getColumnIndexOrThrow(COL_CATEGORIA)) ?: "",
            activo = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACTIVO)) == 1,
            duracion = cursor.getString(cursor.getColumnIndexOrThrow(COL_DURACION)) ?: "",
            nivel = cursor.getString(cursor.getColumnIndexOrThrow(COL_NIVEL)) ?: ""
        )
    }

    private fun cursorToNota(cursor: Cursor): Nota {
        return Nota(
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
            alumnoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ALUMNO_ID)),
            cursoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CURSO_ID)),
            tituloCurso = cursor.getString(cursor.getColumnIndexOrThrow("titulo_curso")) ?: "",
            nota = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_PROMEDIO)),
            comentario = cursor.getString(cursor.getColumnIndexOrThrow(COL_COMENTARIO)) ?: ""
        )
    }

    private fun cursorToHorario(cursor: Cursor): Horario {
        return Horario(
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
            cursoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CURSO_ID)),
            nombreCurso = cursor.getString(cursor.getColumnIndexOrThrow("nombre_curso")) ?: "",
            dia = cursor.getString(cursor.getColumnIndexOrThrow(COL_DIA)),
            horaInicio = cursor.getString(cursor.getColumnIndexOrThrow(COL_HORA_INICIO)),
            horaFin = cursor.getString(cursor.getColumnIndexOrThrow(COL_HORA_FIN)),
            aula = cursor.getString(cursor.getColumnIndexOrThrow(COL_AULA))
        )
    }
}