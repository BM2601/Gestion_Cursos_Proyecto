package com.example.gestioncursos.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.gestioncursos.models.Curso
import com.example.gestioncursos.models.Usuario
import com.example.gestioncursos.models.Material
import com.example.gestioncursos.models.Horario
import com.example.gestioncursos.models.Tarea
import com.example.gestioncursos.models.Nota

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "gestion_cursos.db"
        const val DATABASE_VERSION = 4   // subido de 3 a 4 por el módulo de usuarios

        // Tablas
        const val TABLE_USUARIOS = "usuarios"
        const val TABLE_CURSOS = "cursos"
        const val TABLE_INSCRIPCIONES = "inscripciones"
        const val TABLE_MATERIALES = "materiales"
        const val TABLE_HORARIOS = "horarios"
        const val TABLE_TAREAS = "tareas"
        const val TABLE_NOTAS = "notas"

        const val COL_FECHA_LIMITE = "fecha_limite"
        const val COL_ESTADO = "estado"

        // Columnas Usuarios
        const val COL_ID = "id"
        const val COL_NOMBRE = "nombre"
        const val COL_EMAIL = "email"
        const val COL_PASSWORD = "password"
        const val COL_ROL = "rol" // alumno, profesor, admin
        const val COL_BLOQUEADO = "bloqueado"
        const val COL_CODIGO_ESTUDIANTE = "codigo_estudiante"
        const val COL_TELEFONO = "telefono"

        // Columnas Cursos
        const val COL_TITULO = "titulo"
        const val COL_DESCRIPCION = "descripcion"
        const val COL_PROFESOR_ID = "profesor_id"
        const val COL_CATEGORIA = "categoria"
        const val COL_ACTIVO = "activo"
        const val COL_IMAGEN_URL = "imagen_url"
        const val COL_DURACION = "duracion"
        const val COL_NIVEL = "nivel"

        // Columnas Materiales
        const val COL_CURSO_ID = "curso_id"
        const val COL_NOMBRE_ARCHIVO = "nombre_archivo"
        const val COL_RUTA_ARCHIVO = "ruta_archivo"
        const val COL_FECHA_SUBIDA = "fecha_subida"

        // Columnas Horarios
        const val COL_DIA = "dia"
        const val COL_HORA_INICIO = "hora_inicio"
        const val COL_HORA_FIN = "hora_fin"
        const val COL_AULA = "aula"

        // Columnas Notas
        const val COL_ALUMNO_ID = "alumno_id"
        const val COL_NOTA = "nota"
        const val COL_COMENTARIO = "comentario"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE_USUARIOS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NOMBRE TEXT NOT NULL,
                $COL_EMAIL TEXT UNIQUE NOT NULL,
                $COL_PASSWORD TEXT NOT NULL,
                $COL_ROL TEXT NOT NULL,
                $COL_BLOQUEADO INTEGER DEFAULT 0,
                $COL_CODIGO_ESTUDIANTE TEXT,
                $COL_TELEFONO TEXT
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_CURSOS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITULO TEXT NOT NULL,
                $COL_DESCRIPCION TEXT,
                $COL_PROFESOR_ID INTEGER,
                $COL_CATEGORIA TEXT,
                $COL_ACTIVO INTEGER DEFAULT 1,
                $COL_IMAGEN_URL TEXT,
                $COL_DURACION TEXT,
                $COL_NIVEL TEXT,
                FOREIGN KEY($COL_PROFESOR_ID) REFERENCES $TABLE_USUARIOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_INSCRIPCIONES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                alumno_id INTEGER,
                $COL_CURSO_ID INTEGER,
                fecha_inscripcion TEXT,
                FOREIGN KEY(alumno_id) REFERENCES $TABLE_USUARIOS($COL_ID),
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_MATERIALES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_CURSO_ID INTEGER,
                $COL_NOMBRE_ARCHIVO TEXT,
                $COL_RUTA_ARCHIVO TEXT,
                $COL_FECHA_SUBIDA TEXT,
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_HORARIOS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_CURSO_ID INTEGER,
                $COL_DIA TEXT,
                $COL_HORA_INICIO TEXT,
                $COL_HORA_FIN TEXT,
                $COL_AULA TEXT,
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_TAREAS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITULO TEXT NOT NULL,
                $COL_DESCRIPCION TEXT,
                $COL_CURSO_ID INTEGER,
                $COL_FECHA_LIMITE TEXT,
                $COL_ESTADO TEXT,
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        db.execSQL("""
            CREATE TABLE $TABLE_NOTAS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ALUMNO_ID INTEGER,
                $COL_CURSO_ID INTEGER,
                $COL_NOTA REAL,
                $COL_COMENTARIO TEXT,
                FOREIGN KEY($COL_ALUMNO_ID) REFERENCES $TABLE_USUARIOS($COL_ID),
                FOREIGN KEY($COL_CURSO_ID) REFERENCES $TABLE_CURSOS($COL_ID)
            )
        """)

        // Insertar datos de prueba
        insertarDatosPrueba(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NOTAS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_TAREAS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_HORARIOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MATERIALES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_INSCRIPCIONES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CURSOS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USUARIOS")
        onCreate(db)
    }

    private fun insertarDatosPrueba(db: SQLiteDatabase) {
        // Usuarios de prueba
        val usuarios = listOf(
            ContentValues().apply {
                put(COL_NOMBRE, "Admin Principal"); put(COL_EMAIL, "admin@edu.com")
                put(COL_PASSWORD, "admin123"); put(COL_ROL, "admin")
                put(COL_BLOQUEADO, 0)
            },
            ContentValues().apply {
                put(COL_NOMBRE, "Prof. García"); put(COL_EMAIL, "profesor@edu.com")
                put(COL_PASSWORD, "prof123"); put(COL_ROL, "profesor")
                put(COL_BLOQUEADO, 0)
            },
            ContentValues().apply {
                put(COL_NOMBRE, "Juan Alumno"); put(COL_EMAIL, "alumno@edu.com")
                put(COL_PASSWORD, "alum123"); put(COL_ROL, "alumno")
                put(COL_BLOQUEADO, 0)
                put(COL_CODIGO_ESTUDIANTE, "EST-2024-001")
                put(COL_TELEFONO, "999111222")
            }
        )
        usuarios.forEach { db.insert(TABLE_USUARIOS, null, it) }

        // Cursos de prueba
        val cursos = listOf(
            ContentValues().apply {
                put(COL_TITULO, "Kotlin Avanzado"); put(COL_DESCRIPCION, "Aprende Kotlin desde cero hasta experto")
                put(COL_PROFESOR_ID, 2); put(COL_CATEGORIA, "Programación")
                put(COL_ACTIVO, 1); put(COL_DURACION, "40 horas"); put(COL_NIVEL, "Avanzado")
            },
            ContentValues().apply {
                put(COL_TITULO, "Diseño UI/UX"); put(COL_DESCRIPCION, "Fundamentos del diseño de interfaces")
                put(COL_PROFESOR_ID, 2); put(COL_CATEGORIA, "Diseño")
                put(COL_ACTIVO, 1); put(COL_DURACION, "25 horas"); put(COL_NIVEL, "Intermedio")
            },
            ContentValues().apply {
                put(COL_TITULO, "Base de Datos SQL"); put(COL_DESCRIPCION, "Manejo completo de bases de datos")
                put(COL_PROFESOR_ID, 2); put(COL_CATEGORIA, "Datos")
                put(COL_ACTIVO, 0); put(COL_DURACION, "30 horas"); put(COL_NIVEL, "Básico")
            }
        )
        cursos.forEach { db.insert(TABLE_CURSOS, null, it) }

        // Inscripción de prueba
        val inscripcion = ContentValues().apply {
            put("alumno_id", 3); put(COL_CURSO_ID, 1); put("fecha_inscripcion", "2024-01-15")
        }
        db.insert(TABLE_INSCRIPCIONES, null, inscripcion)

        // Nota de prueba
        val nota = ContentValues().apply {
            put(COL_ALUMNO_ID, 3); put(COL_CURSO_ID, 1)
            put(COL_NOTA, 17.5); put(COL_COMENTARIO, "Excelente desempeño")
        }
        db.insert(TABLE_NOTAS, null, nota)
    }

    // ============ TAREAS ============
    fun insertarTarea(tarea: Tarea): Long {
        val db = writableDatabase
        val valores = ContentValues()
        valores.put(COL_TITULO, tarea.titulo)
        valores.put(COL_DESCRIPCION, tarea.descripcion)
        valores.put(COL_CURSO_ID, tarea.curso)
        valores.put(COL_FECHA_LIMITE, tarea.fechaLimite)
        valores.put(COL_ESTADO, tarea.estado)
        return db.insert(TABLE_TAREAS, null, valores)
    }

    fun listarTareas(): ArrayList<Tarea> {
        val lista = ArrayList<Tarea>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_TAREAS", null)
        if (cursor.moveToFirst()) {
            do {
                val tarea = Tarea(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                    titulo = cursor.getString(cursor.getColumnIndexOrThrow(COL_TITULO)),
                    descripcion = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPCION)),
                    curso = cursor.getString(cursor.getColumnIndexOrThrow(COL_CURSO_ID)),
                    fechaLimite = cursor.getString(cursor.getColumnIndexOrThrow(COL_FECHA_LIMITE)),
                    estado = cursor.getString(cursor.getColumnIndexOrThrow(COL_ESTADO))
                )
                lista.add(tarea)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return lista
    }

    fun marcarTareaCompletada(id: Int): Int {
        val db = writableDatabase
        val valores = ContentValues()
        valores.put(COL_ESTADO, "Completada")
        return db.update(TABLE_TAREAS, valores, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun eliminarTarea(id: Int): Int {
        val db = writableDatabase
        return db.delete(TABLE_TAREAS, "$COL_ID = ?", arrayOf(id.toString()))
    }

    // ============ USUARIOS (autenticación básica) ============
    fun login(email: String, password: String): Usuario? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_EMAIL=? AND $COL_PASSWORD=?",
            arrayOf(email, password)
        )
        var usuario: Usuario? = null
        if (cursor.moveToFirst()) {
            usuario = cursorToUsuario(cursor)
        }
        cursor.close()
        return usuario
    }

    fun registrarUsuario(nombre: String, email: String, password: String, rol: String): Long {
        val values = ContentValues().apply {
            put(COL_NOMBRE, nombre)
            put(COL_EMAIL, email)
            put(COL_PASSWORD, password)
            put(COL_ROL, rol)
            put(COL_BLOQUEADO, 0)
        }
        return writableDatabase.insert(TABLE_USUARIOS, null, values)
    }

    fun cambiarPassword(usuarioId: Int, nuevaPassword: String): Int {
        val values = ContentValues().apply { put(COL_PASSWORD, nuevaPassword) }
        return writableDatabase.update(TABLE_USUARIOS, values, "$COL_ID=?", arrayOf(usuarioId.toString()))
    }

    fun buscarUsuarioPorEmail(email: String): Usuario? {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_EMAIL=?", arrayOf(email)
        )
        var usuario: Usuario? = null
        if (cursor.moveToFirst()) usuario = cursorToUsuario(cursor)
        cursor.close()
        return usuario
    }

    fun obtenerTodosUsuarios(): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_USUARIOS ORDER BY $COL_ROL, $COL_NOMBRE", null)
        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()
        return lista
    }

    fun obtenerProfesores(): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_USUARIOS WHERE $COL_ROL='profesor'", null)
        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()
        return lista
    }

    // ============ GESTIÓN DE USUARIOS (ADMIN) ============

    fun insertarUsuario(usuario: Usuario): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NOMBRE, usuario.nombre)
            put(COL_EMAIL, usuario.email)
            put(COL_PASSWORD, usuario.password)
            put(COL_ROL, usuario.rol)
            put(COL_BLOQUEADO, 0)
            put(COL_CODIGO_ESTUDIANTE, usuario.codigoEstudiante)
            put(COL_TELEFONO, usuario.telefono)
        }
        return db.insert(TABLE_USUARIOS, null, values)
    }

    fun actualizarUsuario(usuario: Usuario): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NOMBRE, usuario.nombre)
            put(COL_EMAIL, usuario.email)
            put(COL_ROL, usuario.rol)
            put(COL_CODIGO_ESTUDIANTE, usuario.codigoEstudiante)
            put(COL_TELEFONO, usuario.telefono)
            if (usuario.password.isNotEmpty()) put(COL_PASSWORD, usuario.password)
        }
        return db.update(TABLE_USUARIOS, values, "$COL_ID=?", arrayOf(usuario.id.toString()))
    }

    fun eliminarUsuario(usuarioId: Int): Int {
        val db = writableDatabase
        db.delete(TABLE_NOTAS, "$COL_ALUMNO_ID=?", arrayOf(usuarioId.toString()))
        db.delete(TABLE_INSCRIPCIONES, "alumno_id=?", arrayOf(usuarioId.toString()))
        return db.delete(TABLE_USUARIOS, "$COL_ID=?", arrayOf(usuarioId.toString()))
    }

    fun toggleBloqueoUsuario(usuarioId: Int, bloqueado: Boolean): Int {
        val db = writableDatabase
        val values = ContentValues().apply { put(COL_BLOQUEADO, if (bloqueado) 1 else 0) }
        return db.update(TABLE_USUARIOS, values, "$COL_ID=?", arrayOf(usuarioId.toString()))
    }

    fun cambiarRolUsuario(usuarioId: Int, nuevoRol: String): Int {
        val db = writableDatabase
        val values = ContentValues().apply { put(COL_ROL, nuevoRol) }
        return db.update(TABLE_USUARIOS, values, "$COL_ID=?", arrayOf(usuarioId.toString()))
    }

    fun obtenerUsuarioPorId(usuarioId: Int): Usuario? {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_USUARIOS WHERE $COL_ID=?", arrayOf(usuarioId.toString()))
        var usuario: Usuario? = null
        if (cursor.moveToFirst()) usuario = cursorToUsuario(cursor)
        cursor.close()
        return usuario
    }

    fun buscarUsuarios(query: String): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val db = readableDatabase
        val param = "%$query%"
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_USUARIOS WHERE $COL_NOMBRE LIKE ? OR $COL_EMAIL LIKE ?",
            arrayOf(param, param)
        )
        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()
        return lista
    }

    private fun cursorToUsuario(cursor: android.database.Cursor): Usuario {
        return Usuario(
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
            nombre = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOMBRE)),
            email = cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL)),
            rol = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROL)),
            bloqueado = try { cursor.getInt(cursor.getColumnIndexOrThrow(COL_BLOQUEADO)) == 1 } catch (e: Exception) { false },
            codigoEstudiante = try { cursor.getString(cursor.getColumnIndexOrThrow(COL_CODIGO_ESTUDIANTE)) ?: "" } catch (e: Exception) { "" },
            telefono = try { cursor.getString(cursor.getColumnIndexOrThrow(COL_TELEFONO)) ?: "" } catch (e: Exception) { "" }
        )
    }

    // ============ PERFIL DEL ALUMNO ============
    fun actualizarPerfilAlumno(usuarioId: Int, nombre: String, telefono: String): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NOMBRE, nombre)
            put(COL_TELEFONO, telefono)
        }
        return db.update(TABLE_USUARIOS, values, "$COL_ID=?", arrayOf(usuarioId.toString()))
    }

    // ============ NOTAS ============
    fun asignarNota(alumnoId: Int, cursoId: Int, nota: Double, comentario: String): Long {
        val db = writableDatabase
        val existe = db.rawQuery(
            "SELECT $COL_ID FROM $TABLE_NOTAS WHERE $COL_ALUMNO_ID=? AND $COL_CURSO_ID=?",
            arrayOf(alumnoId.toString(), cursoId.toString())
        )
        val yaExiste = existe.moveToFirst()
        val notaIdExistente = if (yaExiste) existe.getInt(existe.getColumnIndexOrThrow(COL_ID)) else -1
        existe.close()

        val values = ContentValues().apply {
            put(COL_ALUMNO_ID, alumnoId)
            put(COL_CURSO_ID, cursoId)
            put(COL_NOTA, nota)
            put(COL_COMENTARIO, comentario)
        }

        return if (yaExiste) {
            db.update(TABLE_NOTAS, values, "$COL_ID=?", arrayOf(notaIdExistente.toString())).toLong()
        } else {
            db.insert(TABLE_NOTAS, null, values)
        }
    }

    fun obtenerNotasDelAlumno(alumnoId: Int): List<Nota> {
        val lista = mutableListOf<Nota>()
        val db = readableDatabase
        val query = """
            SELECT n.*, c.$COL_TITULO as titulo_curso
            FROM $TABLE_NOTAS n
            INNER JOIN $TABLE_CURSOS c ON n.$COL_CURSO_ID = c.$COL_ID
            WHERE n.$COL_ALUMNO_ID = ?
        """
        val cursor = db.rawQuery(query, arrayOf(alumnoId.toString()))
        while (cursor.moveToNext()) {
            lista.add(Nota(
                id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                alumnoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ALUMNO_ID)),
                cursoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CURSO_ID)),
                tituloCurso = cursor.getString(cursor.getColumnIndexOrThrow("titulo_curso")),
                nota = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_NOTA)),
                comentario = cursor.getString(cursor.getColumnIndexOrThrow(COL_COMENTARIO)) ?: ""
            ))
        }
        cursor.close()
        return lista
    }

    fun obtenerNotaDeAlumnoEnCurso(alumnoId: Int, cursoId: Int): Nota? {
        val db = readableDatabase
        val query = """
            SELECT n.*, c.$COL_TITULO as titulo_curso
            FROM $TABLE_NOTAS n
            INNER JOIN $TABLE_CURSOS c ON n.$COL_CURSO_ID = c.$COL_ID
            WHERE n.$COL_ALUMNO_ID = ? AND n.$COL_CURSO_ID = ?
        """
        val cursor = db.rawQuery(query, arrayOf(alumnoId.toString(), cursoId.toString()))
        var nota: Nota? = null
        if (cursor.moveToFirst()) {
            nota = Nota(
                id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                alumnoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ALUMNO_ID)),
                cursoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CURSO_ID)),
                tituloCurso = cursor.getString(cursor.getColumnIndexOrThrow("titulo_curso")),
                nota = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_NOTA)),
                comentario = cursor.getString(cursor.getColumnIndexOrThrow(COL_COMENTARIO)) ?: ""
            )
        }
        cursor.close()
        return nota
    }

    fun calcularPromedioAlumno(alumnoId: Int): Double {
        val notas = obtenerNotasDelAlumno(alumnoId)
        if (notas.isEmpty()) return 0.0
        return notas.map { it.nota }.average()
    }

    // ============ CURSOS ============
    fun obtenerTodosCursos(): List<Curso> {
        val lista = mutableListOf<Curso>()
        val db = readableDatabase
        val query = """
            SELECT c.*, u.$COL_NOMBRE as nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
        """
        val cursor = db.rawQuery(query, null)
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()
        return lista
    }

    fun obtenerCursosActivos(): List<Curso> {
        val lista = mutableListOf<Curso>()
        val db = readableDatabase
        val query = """
            SELECT c.*, u.$COL_NOMBRE as nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            WHERE c.$COL_ACTIVO = 1
        """
        val cursor = db.rawQuery(query, null)
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()
        return lista
    }

    fun obtenerCursosDelProfesor(profesorId: Int): List<Curso> {
        val lista = mutableListOf<Curso>()
        val db = readableDatabase
        val query = """
            SELECT c.*, u.$COL_NOMBRE as nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            WHERE c.$COL_PROFESOR_ID = ?
        """
        val cursor = db.rawQuery(query, arrayOf(profesorId.toString()))
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()
        return lista
    }

    fun obtenerCursosDelAlumno(alumnoId: Int): List<Curso> {
        val lista = mutableListOf<Curso>()
        val db = readableDatabase
        val query = """
            SELECT c.*, u.$COL_NOMBRE as nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            INNER JOIN $TABLE_INSCRIPCIONES i ON c.$COL_ID = i.$COL_CURSO_ID
            WHERE i.alumno_id = ?
        """
        val cursor = db.rawQuery(query, arrayOf(alumnoId.toString()))
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()
        return lista
    }

    fun buscarCursos(query: String): List<Curso> {
        val lista = mutableListOf<Curso>()
        val db = readableDatabase
        val sql = """
            SELECT c.*, u.$COL_NOMBRE as nombre_profesor
            FROM $TABLE_CURSOS c
            LEFT JOIN $TABLE_USUARIOS u ON c.$COL_PROFESOR_ID = u.$COL_ID
            WHERE c.$COL_ACTIVO = 1
            AND (c.$COL_TITULO LIKE ? OR c.$COL_DESCRIPCION LIKE ? OR c.$COL_CATEGORIA LIKE ?)
        """
        val param = "%$query%"
        val cursor = db.rawQuery(sql, arrayOf(param, param, param))
        while (cursor.moveToNext()) lista.add(cursorToCurso(cursor))
        cursor.close()
        return lista
    }

    fun insertarCurso(curso: Curso): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_TITULO, curso.titulo)
            put(COL_DESCRIPCION, curso.descripcion)
            put(COL_PROFESOR_ID, curso.profesorId)
            put(COL_CATEGORIA, curso.categoria)
            put(COL_ACTIVO, if (curso.activo) 1 else 0)
            put(COL_DURACION, curso.duracion)
            put(COL_NIVEL, curso.nivel)
        }
        return db.insert(TABLE_CURSOS, null, values)
    }

    fun actualizarCurso(curso: Curso): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_TITULO, curso.titulo)
            put(COL_DESCRIPCION, curso.descripcion)
            put(COL_PROFESOR_ID, curso.profesorId)
            put(COL_CATEGORIA, curso.categoria)
            put(COL_ACTIVO, if (curso.activo) 1 else 0)
            put(COL_DURACION, curso.duracion)
            put(COL_NIVEL, curso.nivel)
        }
        return db.update(TABLE_CURSOS, values, "$COL_ID=?", arrayOf(curso.id.toString()))
    }

    fun eliminarCurso(cursoId: Int): Int {
        val db = writableDatabase
        db.delete(TABLE_INSCRIPCIONES, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_MATERIALES, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_HORARIOS, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_TAREAS, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        db.delete(TABLE_NOTAS, "$COL_CURSO_ID=?", arrayOf(cursoId.toString()))
        return db.delete(TABLE_CURSOS, "$COL_ID=?", arrayOf(cursoId.toString()))
    }

    fun toggleEstadoCurso(cursoId: Int, activo: Boolean): Int {
        val db = writableDatabase
        val values = ContentValues().apply { put(COL_ACTIVO, if (activo) 1 else 0) }
        return db.update(TABLE_CURSOS, values, "$COL_ID=?", arrayOf(cursoId.toString()))
    }

    fun asignarProfesor(cursoId: Int, profesorId: Int): Int {
        val db = writableDatabase
        val values = ContentValues().apply { put(COL_PROFESOR_ID, profesorId) }
        return db.update(TABLE_CURSOS, values, "$COL_ID=?", arrayOf(cursoId.toString()))
    }

    // ============ INSCRIPCIONES ============
    fun inscribirAlumno(alumnoId: Int, cursoId: Int): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("alumno_id", alumnoId)
            put(COL_CURSO_ID, cursoId)
            put("fecha_inscripcion", java.text.SimpleDateFormat("yyyy-MM-dd",
                java.util.Locale.getDefault()).format(java.util.Date()))
        }
        return db.insert(TABLE_INSCRIPCIONES, null, values)
    }

    fun estaInscrito(alumnoId: Int, cursoId: Int): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COL_ID FROM $TABLE_INSCRIPCIONES WHERE alumno_id=? AND $COL_CURSO_ID=?",
            arrayOf(alumnoId.toString(), cursoId.toString())
        )
        val result = cursor.moveToFirst()
        cursor.close()
        return result
    }

    fun obtenerAlumnosDelCurso(cursoId: Int): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val db = readableDatabase
        val query = """
            SELECT u.* FROM $TABLE_USUARIOS u
            INNER JOIN $TABLE_INSCRIPCIONES i ON u.$COL_ID = i.alumno_id
            WHERE i.$COL_CURSO_ID = ?
        """
        val cursor = db.rawQuery(query, arrayOf(cursoId.toString()))
        while (cursor.moveToNext()) lista.add(cursorToUsuario(cursor))
        cursor.close()
        return lista
    }

    // ============ MATERIALES ============
    fun insertarMaterial(material: Material): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_CURSO_ID, material.cursoId)
            put(COL_NOMBRE_ARCHIVO, material.nombreArchivo)
            put(COL_RUTA_ARCHIVO, material.rutaArchivo)
            put(COL_FECHA_SUBIDA, material.fechaSubida)
        }
        return db.insert(TABLE_MATERIALES, null, values)
    }

    fun obtenerMaterialesDeCurso(cursoId: Int): List<Material> {
        val lista = mutableListOf<Material>()
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_MATERIALES WHERE $COL_CURSO_ID=?",
            arrayOf(cursoId.toString())
        )
        while (cursor.moveToNext()) {
            lista.add(Material(
                id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                cursoId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CURSO_ID)),
                nombreArchivo = cursor.getString(cursor.getColumnIndexOrThrow(COL_NOMBRE_ARCHIVO)),
                rutaArchivo = cursor.getString(cursor.getColumnIndexOrThrow(COL_RUTA_ARCHIVO)),
                fechaSubida = cursor.getString(cursor.getColumnIndexOrThrow(COL_FECHA_SUBIDA))
            ))
        }
        cursor.close()
        return lista
    }

    fun eliminarMaterial(materialId: Int): Int {
        val db = writableDatabase
        return db.delete(TABLE_MATERIALES, "$COL_ID=?", arrayOf(materialId.toString()))
    }

    private fun cursorToCurso(cursor: android.database.Cursor): Curso {
        return Curso(
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
            titulo = cursor.getString(cursor.getColumnIndexOrThrow(COL_TITULO)),
            descripcion = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPCION)) ?: "",
            profesorId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_PROFESOR_ID)),
            nombreProfesor = try { cursor.getString(cursor.getColumnIndexOrThrow("nombre_profesor")) } catch (e: Exception) { "" },
            categoria = cursor.getString(cursor.getColumnIndexOrThrow(COL_CATEGORIA)) ?: "",
            activo = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACTIVO)) == 1,
            duracion = cursor.getString(cursor.getColumnIndexOrThrow(COL_DURACION)) ?: "",
            nivel = cursor.getString(cursor.getColumnIndexOrThrow(COL_NIVEL)) ?: ""
        )
    }

    // ============ HORARIOS ============
    fun insertarHorario(horario: Horario): Long {
        val values = ContentValues().apply {
            put(COL_CURSO_ID, horario.cursoId)
            put(COL_DIA, horario.dia)
            put(COL_HORA_INICIO, horario.horaInicio)
            put(COL_HORA_FIN, horario.horaFin)
            put(COL_AULA, horario.aula)
        }
        return writableDatabase.insert(TABLE_HORARIOS, null, values)
    }

    fun obtenerHorarios(): List<Horario> {
        val lista = mutableListOf<Horario>()
        val query = """
            SELECT h.*, c.titulo
            FROM $TABLE_HORARIOS h
            INNER JOIN $TABLE_CURSOS c ON h.$COL_CURSO_ID = c.$COL_ID
        """
        val cursor = readableDatabase.rawQuery(query, null)
        while (cursor.moveToNext()) {
            lista.add(Horario(
                id = cursor.getInt(0), cursoId = cursor.getInt(1), dia = cursor.getString(2),
                horaInicio = cursor.getString(3), horaFin = cursor.getString(4),
                aula = cursor.getString(5), nombreCurso = cursor.getString(6)
            ))
        }
        cursor.close()
        return lista
    }

    fun obtenerHorariosProfesor(profesorId: Int): List<Horario> {
        val lista = mutableListOf<Horario>()
        val query = """
            SELECT h.*, c.titulo
            FROM $TABLE_HORARIOS h
            INNER JOIN $TABLE_CURSOS c ON h.$COL_CURSO_ID = c.$COL_ID
            WHERE c.$COL_PROFESOR_ID = ?
        """
        val cursor = readableDatabase.rawQuery(query, arrayOf(profesorId.toString()))
        while (cursor.moveToNext()) {
            lista.add(Horario(
                id = cursor.getInt(0), cursoId = cursor.getInt(1), dia = cursor.getString(2),
                horaInicio = cursor.getString(3), horaFin = cursor.getString(4),
                aula = cursor.getString(5), nombreCurso = cursor.getString(6)
            ))
        }
        cursor.close()
        return lista
    }

    fun obtenerHorariosAlumno(alumnoId: Int): List<Horario> {
        val lista = mutableListOf<Horario>()
        val query = """
            SELECT h.*, c.titulo
            FROM $TABLE_HORARIOS h
            INNER JOIN $TABLE_CURSOS c ON h.$COL_CURSO_ID = c.$COL_ID
            INNER JOIN $TABLE_INSCRIPCIONES i ON c.$COL_ID = i.$COL_CURSO_ID
            WHERE i.alumno_id = ?
        """
        val cursor = readableDatabase.rawQuery(query, arrayOf(alumnoId.toString()))
        while (cursor.moveToNext()) {
            lista.add(Horario(
                id = cursor.getInt(0), cursoId = cursor.getInt(1), dia = cursor.getString(2),
                horaInicio = cursor.getString(3), horaFin = cursor.getString(4),
                aula = cursor.getString(5), nombreCurso = cursor.getString(6)
            ))
        }
        cursor.close()
        return lista
    }

    fun obtenerProximaClase(alumnoId: Int): Horario? {
        val horarios = obtenerHorariosAlumno(alumnoId)
        if (horarios.isEmpty()) return null

        val diasSemana = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
        val calendario = java.util.Calendar.getInstance()
        val diaActual = calendario.get(java.util.Calendar.DAY_OF_WEEK)

        val indiceActual = when (diaActual) {
            java.util.Calendar.MONDAY -> 0
            java.util.Calendar.TUESDAY -> 1
            java.util.Calendar.WEDNESDAY -> 2
            java.util.Calendar.THURSDAY -> 3
            java.util.Calendar.FRIDAY -> 4
            java.util.Calendar.SATURDAY -> 5
            else -> 6
        }

        return horarios.minByOrNull { horario ->
            val indiceHorario = diasSemana.indexOf(horario.dia)
            if (indiceHorario >= indiceActual) indiceHorario - indiceActual
            else 7 - (indiceActual - indiceHorario)
        }
    }
}