package com.example.gestioncursos.activities.alumno

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.example.gestioncursos.R
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import java.io.File

class DetalleCursoActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_curso)
        db = DatabaseHelper(this)

        val cursoId = intent.getIntExtra("curso_id", 0)
        val curso = db.obtenerTodosCursos().find { it.id == cursoId } ?: return

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarDetalle)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener {
            startActivity(
                Intent(this, AlumnoDashboardActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
            )
            finish()
        }

        findViewById<TextView>(R.id.tvTituloDetalle).text = curso.titulo
        findViewById<TextView>(R.id.tvDescripcionDetalle).text = curso.descripcion
        findViewById<TextView>(R.id.tvProfesorDetalle).text = "Profesor: ${curso.nombreProfesor}"
        findViewById<TextView>(R.id.tvCategoriaDetalle).text = curso.categoria
        findViewById<TextView>(R.id.tvNivelDetalle).text = curso.nivel
        findViewById<TextView>(R.id.tvDuracionDetalle).text = curso.duracion
        findViewById<Chip>(R.id.chipCategoriaDet).text = curso.categoria

        val materiales = db.obtenerMaterialesDeCurso(cursoId)
        val tvMateriales = findViewById<TextView>(R.id.tvMateriales)
        val btnDescargar = findViewById<MaterialButton>(R.id.btnDescargarPDF)

        val btnVolver = findViewById<MaterialButton>(R.id.btnVolver)
        btnVolver.setOnClickListener {
            startActivity(
                Intent(this, AlumnoDashboardActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
            )
            finish()
        }

        if (materiales.isEmpty()) {
            tvMateriales.text = "Sin materiales disponibles aún"
            btnDescargar.isEnabled = false
            btnDescargar.text = "Sin material disponible"
        } else {
            tvMateriales.text = materiales.joinToString("\n") { "📄 ${it.nombreArchivo}" }
            btnDescargar.setOnClickListener {
                abrirPDF(materiales.first().rutaArchivo, materiales.first().nombreArchivo)
            }
        }
    }

    private fun abrirPDF(rutaArchivo: String, nombreArchivo: String) {
        try {
            val uri: Uri

            if (rutaArchivo.startsWith("/") && File(rutaArchivo).exists()) {
                val file = File(rutaArchivo)
                uri = FileProvider.getUriForFile(
                    this,
                    "${packageName}.fileprovider",
                    file
                )
            } else {
                uri = Uri.parse(rutaArchivo)
            }

            val pdfIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            }

            if (pdfIntent.resolveActivity(packageManager) != null) {
                startActivity(pdfIntent)
            } else {
                startActivity(Intent.createChooser(pdfIntent, "Abrir PDF con..."))
            }
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "No se puede abrir el PDF. Instala un lector de PDF.",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}