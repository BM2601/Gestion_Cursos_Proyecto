package com.example.gestioncursos.activities.profesor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputFilter
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.database.DatabaseHelper
import com.example.gestioncursos.models.Curso
import com.example.gestioncursos.models.Material
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CrearEditarCursoActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var cursoId = 0
    private var pdfUri: Uri? = null
    private var pdfNombre: String = ""

    private val niveles = arrayOf("Básico", "Intermedio", "Avanzado")

    private val categorias = arrayOf(
        "Programación",
        "Diseño Gráfico",
        "Ofimática",
        "Base de Datos",
        "Desarrollo Web",
        "Redes y Telecomunicaciones",
        "Ciberseguridad",
        "Soporte Técnico",
        "Hardware y Ensamblaje",
        "Inteligencia Artificial",
        "Desarrollo Móvil",
        "Marketing Digital"
    )

    private lateinit var tvNombrePDF: TextView

    private val pdfPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                pdfUri = uri
                pdfNombre = obtenerNombreArchivo(uri) ?: "material.pdf"
                tvNombrePDF.text = "📄 $pdfNombre"
                Toast.makeText(this, "PDF seleccionado: $pdfNombre", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_editar_curso)

        db = DatabaseHelper(this)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val tvTituloForm = findViewById<TextView>(R.id.tvTituloForm)
        val etTitulo = findViewById<TextInputEditText>(R.id.etTituloCurso)
        val etDescripcion = findViewById<TextInputEditText>(R.id.etDescripcionCurso)
        val etDuracion = findViewById<TextInputEditText>(R.id.etDuracionCurso)
        val spinnerCategoria = findViewById<Spinner>(R.id.spinnerCategoria)
        val spinnerNivel = findViewById<Spinner>(R.id.spinnerNivel)
        val btnGuardar = findViewById<MaterialButton>(R.id.btnGuardarCurso)
        val btnSeleccionarPDF = findViewById<MaterialButton>(R.id.btnSeleccionarPDF)
        tvNombrePDF = findViewById(R.id.tvNombrePDF)

        btnBack.setOnClickListener { finish() }

        val adapterCategoria = ArrayAdapter(this, android.R.layout.simple_spinner_item, categorias)
        adapterCategoria.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategoria.adapter = adapterCategoria

        val adapterNivel = ArrayAdapter(this, android.R.layout.simple_spinner_item, niveles)
        adapterNivel.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerNivel.adapter = adapterNivel

        etDuracion.filters = arrayOf(InputFilter { source, _, _, _, _, _ ->
            if (source.matches(Regex("[0-9]*"))) {
                source
            } else {
                Toast.makeText(
                    this,
                    "Ponga solo números en el campo duración",
                    Toast.LENGTH_SHORT
                ).show()
                ""
            }
        })

        cursoId = intent.getIntExtra("curso_id", 0)
        val modo = intent.getStringExtra("modo") ?: "crear"

        if (modo == "editar" && cursoId > 0) {
            tvTituloForm.text = "Editar Curso"
            val curso = db.obtenerTodosCursos().find { it.id == cursoId }

            if (curso != null) {
                etTitulo.setText(curso.titulo)
                etDescripcion.setText(curso.descripcion)
                etDuracion.setText(curso.duracion)

                val indexCategoria = categorias.indexOf(curso.categoria)
                if (indexCategoria >= 0) spinnerCategoria.setSelection(indexCategoria)

                val indexNivel = niveles.indexOf(curso.nivel)
                if (indexNivel >= 0) spinnerNivel.setSelection(indexNivel)

                val materiales = db.obtenerMaterialesDeCurso(cursoId)
                if (materiales.isNotEmpty()) {
                    tvNombrePDF.text = "📄 ${materiales.first().nombreArchivo}"
                }
            }
        } else {
            tvTituloForm.text = "Crear Nuevo Curso"
        }

        btnSeleccionarPDF.setOnClickListener {
            abrirSelectorPDF()
        }

        btnGuardar.setOnClickListener {
            val titulo = etTitulo.text.toString().trim()
            val descripcion = etDescripcion.text.toString().trim()
            val categoria = spinnerCategoria.selectedItem.toString()
            val duracion = etDuracion.text.toString().trim()
            val nivel = spinnerNivel.selectedItem.toString()

            if (
                titulo.isEmpty() ||
                descripcion.isEmpty() ||
                categoria.isEmpty() ||
                duracion.isEmpty() ||
                nivel.isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Rellene todos los campos por favor",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val profesorIdIntent = intent.getIntExtra("profesor_id", 0)
            val profesorIdSesion = SessionManager.id(this)

            val profesorIdFinal = when {
                profesorIdIntent > 0 -> profesorIdIntent
                profesorIdSesion != -1 -> profesorIdSesion
                else -> 2
            }

            val curso = Curso(
                id = cursoId,
                titulo = titulo,
                descripcion = descripcion,
                profesorId = profesorIdFinal,
                categoria = categoria,
                activo = true,
                duracion = duracion,
                nivel = nivel
            )

            val nuevoCursoId: Int

            if (modo == "editar" && cursoId > 0) {
                db.actualizarCurso(curso)
                nuevoCursoId = cursoId
                Toast.makeText(this, "Curso actualizado", Toast.LENGTH_SHORT).show()
            } else {
                val insertedId = db.insertarCurso(curso)
                nuevoCursoId = insertedId.toInt()
                Toast.makeText(this, "Curso creado", Toast.LENGTH_SHORT).show()
            }

            if (pdfUri != null && nuevoCursoId > 0) {
                guardarPDFEnApp(pdfUri!!, pdfNombre, nuevoCursoId)
            }

            finish()
        }
    }

    private fun abrirSelectorPDF() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

        pdfPickerLauncher.launch(intent)
    }

    private fun obtenerNombreArchivo(uri: Uri): String? {
        var nombre: String? = null

        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx != -1) nombre = cursor.getString(idx)
            }
        }

        return nombre ?: uri.lastPathSegment
    }

    private fun guardarPDFEnApp(uri: Uri, nombre: String, cursoId: Int) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )

            val pdfDir = File(filesDir, "pdfs")
            if (!pdfDir.exists()) pdfDir.mkdirs()

            val timestamp = SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.getDefault()
            ).format(Date())

            val nombreSanitizado = nombre.replace("[^a-zA-Z0-9._-]".toRegex(), "_")
            val destFile = File(pdfDir, "${timestamp}_${nombreSanitizado}")

            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            val fechaHoy = SimpleDateFormat(
                "dd/MM/yyyy",
                Locale.getDefault()
            ).format(Date())

            val material = Material(
                id = 0,
                cursoId = cursoId,
                nombreArchivo = nombre,
                rutaArchivo = destFile.absolutePath,
                fechaSubida = fechaHoy
            )

            db.insertarMaterial(material)

            Toast.makeText(this, "PDF guardado correctamente", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Error al guardar PDF: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}