package com.example.gestioncursos.activities.admin

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.adapters.UsuarioAdapter
import com.example.gestioncursos.database.DatabaseHelper
import com.example.gestioncursos.models.Usuario
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout

class GestionUsuariosAdminActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var rvUsuarios: RecyclerView
    private lateinit var etFiltro: EditText
    private lateinit var tvContador: TextView
    private var filtroRolActual: String? = null // null = todos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gestion_usuarios_admin)
        db = DatabaseHelper(this)

        rvUsuarios = findViewById(R.id.rvUsuarios)
        rvUsuarios.layoutManager = LinearLayoutManager(this)
        etFiltro = findViewById(R.id.etFiltroUsuarios)
        tvContador = findViewById(R.id.tvTotalUsuarios)

        findViewById<ImageButton>(R.id.btnBackUsuarios).setOnClickListener { finish() }

        findViewById<FloatingActionButton>(R.id.fabCrearUsuario).setOnClickListener {
            mostrarDialogoCrearEditarUsuario(null)
        }

        val tabs = findViewById<TabLayout>(R.id.tabsRoles)
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                filtroRolActual = when (tab?.position) {
                    1 -> "admin"
                    2 -> "profesor"
                    3 -> "alumno"
                    else -> null
                }
                cargarUsuarios()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        etFiltro.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { cargarUsuarios() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        cargarUsuarios()
    }

    override fun onResume() {
        super.onResume()
        cargarUsuarios()
    }

    private fun cargarUsuarios() {
        val query = etFiltro.text.toString()
        var usuarios = if (query.isEmpty()) db.obtenerTodosUsuarios() else db.buscarUsuarios(query)

        filtroRolActual?.let { rol ->
            usuarios = usuarios.filter { it.rol == rol }
        }

        rvUsuarios.adapter = UsuarioAdapter(
            usuarios,
            onEditClick = { usuario -> mostrarDialogoCrearEditarUsuario(usuario) },
            onDeleteClick = { usuario -> confirmarEliminarUsuario(usuario) },
            onToggleBloqueoClick = { usuario -> toggleBloqueo(usuario) },
            onCambiarRolClick = { usuario -> mostrarDialogoCambiarRol(usuario) }
        )

        tvContador.text = "${usuarios.size} usuarios"
    }

    private fun toggleBloqueo(usuario: Usuario) {
        val nuevoEstado = !usuario.bloqueado
        db.toggleBloqueoUsuario(usuario.id, nuevoEstado)
        val msg = if (nuevoEstado) "Usuario bloqueado" else "Usuario desbloqueado"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        cargarUsuarios()
    }

    private fun mostrarDialogoCambiarRol(usuario: Usuario) {
        val roles = arrayOf("admin", "profesor", "alumno")
        val rolesDisplay = arrayOf("Administrador", "Profesor", "Alumno")
        val indiceActual = roles.indexOf(usuario.rol)

        AlertDialog.Builder(this)
            .setTitle("Cambiar rol de ${usuario.nombre}")
            .setSingleChoiceItems(rolesDisplay, indiceActual) { dialog, which ->
                db.cambiarRolUsuario(usuario.id, roles[which])
                Toast.makeText(this, "Rol actualizado a ${rolesDisplay[which]}", Toast.LENGTH_SHORT).show()
                cargarUsuarios()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmarEliminarUsuario(usuario: Usuario) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar Usuario")
            .setMessage("¿Estás seguro de eliminar a '${usuario.nombre}'? Esta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                db.eliminarUsuario(usuario.id)
                Toast.makeText(this, "Usuario eliminado", Toast.LENGTH_SHORT).show()
                cargarUsuarios()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun mostrarDialogoCrearEditarUsuario(usuario: Usuario?) {
        val esEdicion = usuario != null
        val dialogView = layoutInflater.inflate(R.layout.dialog_crear_editar_usuario, null)

        val etNombre = dialogView.findViewById<EditText>(R.id.etNombreDialogUsuario)
        val etEmail = dialogView.findViewById<EditText>(R.id.etEmailDialogUsuario)
        val etPassword = dialogView.findViewById<EditText>(R.id.etPasswordDialogUsuario)
        val etCodigo = dialogView.findViewById<EditText>(R.id.etCodigoDialogUsuario)
        val etTelefono = dialogView.findViewById<EditText>(R.id.etTelefonoDialogUsuario)
        val spinnerRol = dialogView.findViewById<Spinner>(R.id.spinnerRolDialogUsuario)

        val roles = arrayOf("admin", "profesor", "alumno")
        val rolesDisplay = arrayOf("Administrador", "Profesor", "Alumno")
        spinnerRol.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, rolesDisplay
        )

        if (esEdicion) {
            etNombre.setText(usuario!!.nombre)
            etEmail.setText(usuario.email)
            etCodigo.setText(usuario.codigoEstudiante)
            etTelefono.setText(usuario.telefono)
            spinnerRol.setSelection(roles.indexOf(usuario.rol))
            etPassword.hint = "Dejar en blanco para no cambiar"
        }

        AlertDialog.Builder(this)
            .setTitle(if (esEdicion) "Editar Usuario" else "Crear Usuario")
            .setView(dialogView)
            .setPositiveButton(if (esEdicion) "Guardar" else "Crear") { _, _ ->
                val nombre = etNombre.text.toString().trim()
                val email = etEmail.text.toString().trim()
                val password = etPassword.text.toString().trim()
                val codigo = etCodigo.text.toString().trim()
                val telefono = etTelefono.text.toString().trim()
                val rolSeleccionado = roles[spinnerRol.selectedItemPosition]

                if (nombre.isEmpty() || email.isEmpty()) {
                    Toast.makeText(this, "Nombre y correo son requeridos", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (!esEdicion && password.isEmpty()) {
                    Toast.makeText(this, "La contraseña es requerida", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val nuevoUsuario = Usuario(
                    id = usuario?.id ?: 0,
                    nombre = nombre,
                    email = email,
                    password = password,
                    rol = rolSeleccionado,
                    codigoEstudiante = codigo,
                    telefono = telefono
                )

                if (esEdicion) {
                    db.actualizarUsuario(nuevoUsuario)
                    Toast.makeText(this, "Usuario actualizado", Toast.LENGTH_SHORT).show()
                } else {
                    db.insertarUsuario(nuevoUsuario)
                    Toast.makeText(this, "Usuario creado", Toast.LENGTH_SHORT).show()
                }
                cargarUsuarios()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}