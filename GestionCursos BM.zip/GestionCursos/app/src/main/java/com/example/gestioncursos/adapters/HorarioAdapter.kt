package com.example.gestioncursos.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.models.Horario

class HorarioAdapter(
    private val horarios: List<Horario>
) : RecyclerView.Adapter<HorarioAdapter.HorarioViewHolder>() {

    class HorarioViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val tvCurso: TextView = itemView.findViewById(R.id.tvCurso)
        val tvDia: TextView = itemView.findViewById(R.id.tvDia)
        val tvHora: TextView = itemView.findViewById(R.id.tvHora)
        val tvAula: TextView = itemView.findViewById(R.id.tvAula)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HorarioViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_horario, parent, false)

        return HorarioViewHolder(view)
    }

    override fun getItemCount(): Int = horarios.size

    override fun onBindViewHolder(
        holder: HorarioViewHolder,
        position: Int
    ) {

        val horario = horarios[position]

        holder.tvCurso.text = "Curso: ${horario.nombreCurso}"
        holder.tvDia.text = "Día: ${horario.dia}"
        holder.tvHora.text =
            "Horario: ${horario.horaInicio} - ${horario.horaFin}"
        holder.tvAula.text = "Aula: ${horario.aula}"
    }
}