package com.example.gestioncursos.adapters

import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.models.Curso
import com.example.gestioncursos.models.Nota

class HistorialAcademicoAdapter(
    private val cursos: List<Curso>,
    private val notas: List<Nota>
) : RecyclerView.Adapter<HistorialAcademicoAdapter.HistorialViewHolder>() {

    class HistorialViewHolder(val layout: LinearLayout) : RecyclerView.ViewHolder(layout) {
        val tvCurso = TextView(layout.context)
        val tvProfesor = TextView(layout.context)
        val tvNota = TextView(layout.context)

        init {
            layout.orientation = LinearLayout.VERTICAL
            layout.setPadding(32, 24, 32, 24)

            tvCurso.textSize = 18f
            tvProfesor.textSize = 14f
            tvNota.textSize = 16f

            layout.addView(tvCurso)
            layout.addView(tvProfesor)
            layout.addView(tvNota)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistorialViewHolder {
        val layout = LinearLayout(parent.context)
        layout.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return HistorialViewHolder(layout)
    }

    override fun onBindViewHolder(holder: HistorialViewHolder, position: Int) {
        val curso = cursos[position]
        val nota = notas.find { it.cursoId == curso.id }

        holder.tvCurso.text = curso.titulo
        holder.tvProfesor.text = "Profesor: ${curso.nombreProfesor}"
        holder.tvNota.text = "Nota: ${nota?.nota ?: "Sin nota"}"
    }

    override fun getItemCount(): Int = cursos.size
}