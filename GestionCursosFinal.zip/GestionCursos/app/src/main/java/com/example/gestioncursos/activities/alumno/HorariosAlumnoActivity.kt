package com.example.gestioncursos.activities.alumno

import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.adapters.HorarioAdapter
import com.example.gestioncursos.database.DatabaseHelper

class HorariosAlumnoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_horarios_alumno)

        findViewById<ImageButton>(R.id.btnBackAlumnoHorario).setOnClickListener { finish() }

        val recycler = findViewById<RecyclerView>(R.id.recyclerHorariosAlumno)
        recycler.layoutManager = LinearLayoutManager(this)

        // ✅ SessionManager en vez de SesionUsuario
        val alumnoId = SessionManager.id(this)
        val db = DatabaseHelper(this)
        val horarios = db.obtenerHorariosAlumno(alumnoId)

        if (horarios.isEmpty()) {
            Toast.makeText(this, "No tienes horarios asignados", Toast.LENGTH_SHORT).show()
        }

        recycler.adapter = HorarioAdapter(horarios)
    }
}