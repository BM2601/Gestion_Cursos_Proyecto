package com.example.gestioncursos.activities.admin

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.adapters.HorarioAdapter
import com.example.gestioncursos.database.DatabaseHelper
import com.example.gestioncursos.models.Curso
import com.example.gestioncursos.models.Horario

class GestionHorariosAdminActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    private lateinit var spinnerDia: Spinner
    private lateinit var spinnerCursos: Spinner
    private lateinit var etHoraInicio: EditText
    private lateinit var etHoraFin: EditText
    private lateinit var etAula: EditText
    private lateinit var btnGuardar: Button
    private lateinit var recyclerHorarios: RecyclerView
    private lateinit var btnBack: ImageButton

    private var cursos = mutableListOf<Curso>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gestion_horarios_admin)

        db = DatabaseHelper(this)

        spinnerDia = findViewById(R.id.spinnerDia)
        spinnerCursos = findViewById(R.id.spinnerCursos)
        etHoraInicio = findViewById(R.id.etHoraInicio)
        etHoraFin = findViewById(R.id.etHoraFin)
        etAula = findViewById(R.id.etAula)
        btnGuardar = findViewById(R.id.btnGuardarHorario)
        recyclerHorarios = findViewById(R.id.recyclerHorarios)
        btnBack = findViewById(R.id.btnBackHorariosAdmin)

        btnBack.setOnClickListener {
            finish()
        }

        val dias = listOf(
            "Lunes",
            "Martes",
            "Miércoles",
            "Jueves",
            "Viernes",
            "Sábado"
        )

        spinnerDia.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            dias
        )

        cursos = db.obtenerTodosCursos().toMutableList()

        val nombresCursos = cursos.map { it.titulo }

        val adapterCursos = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            nombresCursos
        )

        adapterCursos.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        spinnerCursos.adapter = adapterCursos

        recyclerHorarios.layoutManager = LinearLayoutManager(this)

        cargarHorarios()

        btnGuardar.setOnClickListener {

            val horaInicio = etHoraInicio.text.toString().trim()
            val horaFin = etHoraFin.text.toString().trim()
            val aula = etAula.text.toString().trim()

            val formatoHora = Regex("^([0-9]{1,2}):([0-9]{2})$")

            if (cursos.isEmpty()) {
                Toast.makeText(
                    this,
                    "No hay cursos registrados",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            if (horaInicio.isEmpty()) {
                etHoraInicio.error = "Ingresa la hora de inicio"
                etHoraInicio.requestFocus()
                return@setOnClickListener
            }

            if (!formatoHora.matches(horaInicio)) {
                etHoraInicio.error = "Formato válido: 8:30"
                etHoraInicio.requestFocus()
                return@setOnClickListener
            }

            if (horaFin.isEmpty()) {
                etHoraFin.error = "Ingresa la hora de fin"
                etHoraFin.requestFocus()
                return@setOnClickListener
            }

            if (!formatoHora.matches(horaFin)) {
                etHoraFin.error = "Formato válido: 8:30"
                etHoraFin.requestFocus()
                return@setOnClickListener
            }

            if (aula.isEmpty()) {
                etAula.error = "Ingresa el aula"
                etAula.requestFocus()
                return@setOnClickListener
            }

            if (aula.length > 4) {
                etAula.error = "Máximo 4 caracteres"
                etAula.requestFocus()
                return@setOnClickListener
            }

            val cursoId = cursos[spinnerCursos.selectedItemPosition].id

            val horario = Horario(
                cursoId = cursoId,
                dia = spinnerDia.selectedItem.toString(),
                horaInicio = horaInicio,
                horaFin = horaFin,
                aula = aula
            )

            db.insertarHorario(horario)

            Toast.makeText(
                this,
                "Horario registrado",
                Toast.LENGTH_SHORT
            ).show()

            etHoraInicio.text.clear()
            etHoraFin.text.clear()
            etAula.text.clear()

            cargarHorarios()
        }
    }

    private fun cargarHorarios() {
        recyclerHorarios.adapter = HorarioAdapter(db.obtenerHorarios())
    }
}