package com.example.gestioncursos.activities.profesor

import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class AsignarNotasActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var alumnoId = 0
    private var cursoId = 0

    private lateinit var tilNota1: TextInputLayout
    private lateinit var tilNota2: TextInputLayout
    private lateinit var tilNota3: TextInputLayout

    private lateinit var etNota1: TextInputEditText
    private lateinit var etNota2: TextInputEditText
    private lateinit var etNota3: TextInputEditText
    private lateinit var etComentario: TextInputEditText
    private lateinit var tvPromedio: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asignar_notas)

        db = DatabaseHelper(this)

        alumnoId = intent.getIntExtra("alumno_id", 0)
        cursoId = intent.getIntExtra("curso_id", 0)

        val nombreAlumno = intent.getStringExtra("alumno_nombre") ?: ""
        val tituloCurso = intent.getStringExtra("curso_titulo") ?: ""

        findViewById<TextView>(R.id.tvNombreAlumnoNota).text = nombreAlumno
        findViewById<TextView>(R.id.tvCursoNota).text = tituloCurso
        findViewById<ImageButton>(R.id.btnBackNotas).setOnClickListener { finish() }

        tilNota1 = findViewById(R.id.tilNota1)
        tilNota2 = findViewById(R.id.tilNota2)
        tilNota3 = findViewById(R.id.tilNota3)

        etNota1 = findViewById(R.id.etNota1)
        etNota2 = findViewById(R.id.etNota2)
        etNota3 = findViewById(R.id.etNota3)
        etComentario = findViewById(R.id.etComentarioNota)
        tvPromedio = findViewById(R.id.tvPromedioCalculado)

        val filtroSoloNumeros = InputFilter { source, _, _, _, _, _ ->
            if (source.matches(Regex("[0-9.]*"))) source else ""
        }

        etNota1.filters = arrayOf(filtroSoloNumeros)
        etNota2.filters = arrayOf(filtroSoloNumeros)
        etNota3.filters = arrayOf(filtroSoloNumeros)

        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                calcularPromedioAutomatico()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }

        etNota1.addTextChangedListener(watcher)
        etNota2.addTextChangedListener(watcher)
        etNota3.addTextChangedListener(watcher)

        findViewById<MaterialButton>(R.id.btnGuardarNota).setOnClickListener {
            guardarNota()
        }
    }

    private fun calcularPromedioAutomatico() {
        val n1 = etNota1.text.toString().toDoubleOrNull()
        val n2 = etNota2.text.toString().toDoubleOrNull()
        val n3 = etNota3.text.toString().toDoubleOrNull()

        if (n1 != null && n2 != null && n3 != null) {
            val promedio = (n1 + n2 + n3) / 3
            tvPromedio.text = "Promedio: %.1f".format(promedio)
        } else {
            tvPromedio.text = "Promedio: 0.0"
        }
    }

    private fun guardarNota() {
        tilNota1.error = null
        tilNota2.error = null
        tilNota3.error = null

        val n1 = etNota1.text.toString().toDoubleOrNull()
        val n2 = etNota2.text.toString().toDoubleOrNull()
        val n3 = etNota3.text.toString().toDoubleOrNull()

        if (n1 == null || n2 == null || n3 == null) {
            Toast.makeText(this, "Ponga solo números, no letras", Toast.LENGTH_SHORT).show()

            if (n1 == null) tilNota1.error = "Solo números"
            if (n2 == null) tilNota2.error = "Solo números"
            if (n3 == null) tilNota3.error = "Solo números"

            return
        }

        if (n1 < 0 || n1 > 20 || n2 < 0 || n2 > 20 || n3 < 0 || n3 > 20) {
            Toast.makeText(this, "Las notas deben estar entre 0 y 20", Toast.LENGTH_SHORT).show()

            if (n1 < 0 || n1 > 20) tilNota1.error = "Nota inválida"
            if (n2 < 0 || n2 > 20) tilNota2.error = "Nota inválida"
            if (n3 < 0 || n3 > 20) tilNota3.error = "Nota inválida"

            return
        }

        val promedio = (n1 + n2 + n3) / 3
        val comentario = etComentario.text.toString().trim()

        db.asignarNota(alumnoId, cursoId, n1, n2, n3, promedio, comentario)

        Toast.makeText(this, "Nota guardada correctamente", Toast.LENGTH_SHORT).show()
        finish()
    }
}