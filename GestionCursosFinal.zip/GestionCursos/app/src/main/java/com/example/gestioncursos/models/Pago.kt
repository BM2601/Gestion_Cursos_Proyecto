package com.example.gestioncursos.models


data class Pago(
    val id: Int = 0,
    val alumnoId: Int,
    val concepto: String,
    val monto: Double,
    val fechaVencimiento: String,
    val fechaPago: String = "",
    val estado: String = "Pendiente"
)