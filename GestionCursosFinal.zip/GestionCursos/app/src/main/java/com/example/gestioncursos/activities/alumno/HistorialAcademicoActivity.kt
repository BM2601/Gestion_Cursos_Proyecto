package com.example.gestioncursos.activities.alumno

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.adapters.HistorialAcademicoAdapter
import com.example.gestioncursos.database.DatabaseHelper


class HistorialAcademicoActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial_academico)

        db = DatabaseHelper(this)

        val backId = resources.getIdentifier("btnBackHistorialAcademico", "id", packageName)
        if (backId != 0) {
            findViewById<ImageButton>(backId).setOnClickListener {
                finish()
            }
        }

        val alumnoId = SessionManager.id(this)
        val cursos = db.obtenerCursosDelAlumno(alumnoId)
        val notas = db.obtenerNotasDelAlumno(alumnoId)

        val recyclerId = resources.getIdentifier("rvHistorialAcademico", "id", packageName)
        if (recyclerId != 0) {
            val rv = findViewById<RecyclerView>(recyclerId)
            rv.layoutManager = LinearLayoutManager(this)
            rv.adapter = HistorialAcademicoAdapter(cursos, notas)
        }
    }
}