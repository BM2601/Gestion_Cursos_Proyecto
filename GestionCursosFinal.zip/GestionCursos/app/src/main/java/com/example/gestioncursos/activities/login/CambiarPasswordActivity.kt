package com.example.gestioncursos.activities.login

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton

class CambiarPasswordActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cambiar_password)

        db = DatabaseHelper(this)

        val btnBack = findViewById<ImageButton>(R.id.btnBackPassword)
        val etActual = findViewById<EditText>(R.id.etPasswordActual)
        val etNueva = findViewById<EditText>(R.id.etPasswordNueva)
        val etConfirmar = findViewById<EditText>(R.id.etPasswordConfirmar)
        val btnCambiar = findViewById<MaterialButton>(R.id.btnCambiarPassword)

        btnBack.setOnClickListener {
            finish()
        }

        btnCambiar.setOnClickListener {
            val actual = etActual.text.toString()
            val nueva = etNueva.text.toString()
            val confirmar = etConfirmar.text.toString()

            etActual.error = null
            etNueva.error = null
            etConfirmar.error = null

            if (actual.isEmpty() || nueva.isEmpty() || confirmar.isEmpty()) {
                Toast.makeText(this, "Completa los 3 campos", Toast.LENGTH_SHORT).show()

                if (actual.isEmpty()) etActual.error = "Campo obligatorio"
                if (nueva.isEmpty()) etNueva.error = "Campo obligatorio"
                if (confirmar.isEmpty()) etConfirmar.error = "Campo obligatorio"

                return@setOnClickListener
            }

            val usuarioId = SessionManager.id(this)

            if (usuarioId == -1) {
                Toast.makeText(this, "No hay sesión activa", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val usuario = db.obtenerUsuarioPorId(usuarioId)

            if (usuario == null) {
                Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (actual != usuario.password) {
                etActual.error = "Contraseña incorrecta"
                Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (nueva != confirmar) {
                etConfirmar.error = "Las contraseñas no coinciden"
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            db.cambiarPassword(usuarioId, nueva)

            Toast.makeText(this, "Contraseña actualizada correctamente", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}