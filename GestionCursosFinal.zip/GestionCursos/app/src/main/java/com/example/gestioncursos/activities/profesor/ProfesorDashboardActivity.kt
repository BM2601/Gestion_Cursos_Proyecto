package com.example.gestioncursos.activities.profesor

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.login.LoginActivity
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.adapters.CursoAdapter
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ProfesorDashboardActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var profesorId = 0
    private var nombreProfesor = "Profesor"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profesor_dashboard)

        db = DatabaseHelper(this)

        // ✅ Lee siempre de SessionManager
        profesorId = SessionManager.id(this)
        nombreProfesor = SessionManager.nombre(this)

        findViewById<TextView>(R.id.tvBienvenidaProfesor).text = "Bienvenido, $nombreProfesor"

        findViewById<ImageButton>(R.id.btnConfiguracionProfesor).setOnClickListener {
            startActivity(Intent(this, ConfiguracionProfesorActivity::class.java))
        }

        findViewById<FloatingActionButton>(R.id.fabCrearCurso).setOnClickListener {
            startActivity(
                Intent(this, CrearEditarCursoActivity::class.java).apply {
                    putExtra("modo", "crear")
                }
            )
        }

        findViewById<ImageButton>(R.id.btnLogoutProfesor).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Cerrar Sesión")
                .setMessage("¿Deseas salir de la sesión?")
                .setPositiveButton("Sí") { _, _ -> SessionManager.cerrar(this) }
                .setNegativeButton("No", null)
                .show()
        }

        findViewById<MaterialButton>(R.id.btnMisHorarios).setOnClickListener {
            startActivity(Intent(this, HorariosProfesorActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnGestionTareasProfesor).setOnClickListener {
            startActivity(Intent(this, GestionTareasProfesorActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnAlumnosInscritosProfesor).setOnClickListener {
            abrirSeleccionCursoParaAlumnos()
        }

        cargarCursos()
    }

    override fun onResume() {
        super.onResume()
        cargarCursos()
    }

    private fun cargarCursos() {
        val rvCursos = findViewById<RecyclerView>(R.id.rvCursosProfesor)
        rvCursos.layoutManager = LinearLayoutManager(this)

        val cursos = db.obtenerCursosDelProfesor(profesorId)

        rvCursos.adapter = CursoAdapter(
            cursos,
            onItemClick = { curso -> abrirAlumnosDelCurso(curso.id, curso.titulo) },
            onEditClick = { curso ->
                startActivity(
                    Intent(this, CrearEditarCursoActivity::class.java).apply {
                        putExtra("curso_id", curso.id)
                        putExtra("modo", "editar")
                    }
                )
            },
            onDeleteClick = { curso ->
                AlertDialog.Builder(this)
                    .setTitle("Eliminar Curso")
                    .setMessage("¿Eliminar '${curso.titulo}'?")
                    .setPositiveButton("Sí") { _, _ ->
                        db.eliminarCurso(curso.id)
                        cargarCursos()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            },
            showAdminOptions = true
        )

        val activos = cursos.count { it.activo }
        findViewById<TextView>(R.id.tvTotalCursos).text = cursos.size.toString()
        findViewById<TextView>(R.id.tvCursosActivos).text = activos.toString()
    }

    private fun abrirSeleccionCursoParaAlumnos() {
        val cursos = db.obtenerCursosDelProfesor(profesorId)

        if (cursos.isEmpty()) {
            Toast.makeText(this, "No tienes cursos asignados", Toast.LENGTH_SHORT).show()
            return
        }

        if (cursos.size == 1) {
            abrirAlumnosDelCurso(cursos[0].id, cursos[0].titulo)
            return
        }

        val nombresCursos = cursos.map { it.titulo }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Selecciona un curso")
            .setItems(nombresCursos) { _, position ->
                abrirAlumnosDelCurso(cursos[position].id, cursos[position].titulo)
            }
            .show()
    }

    private fun abrirAlumnosDelCurso(cursoId: Int, cursoTitulo: String) {
        startActivity(
            Intent(this, AlumnosInscritosActivity::class.java).apply {
                putExtra("curso_id", cursoId)
                putExtra("curso_titulo", cursoTitulo)
            }
        )
    }
}