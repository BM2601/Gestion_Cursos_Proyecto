package com.example.gestioncursos.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.adapters.AlumnoAdapter
import com.example.gestioncursos.database.DatabaseHelper

class AlumnosInscritosActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var cursoId = 0
    private var cursoTitulo = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alumnos_inscritos)
        db = DatabaseHelper(this)

        cursoId = intent.getIntExtra("curso_id", 0)
        cursoTitulo = intent.getStringExtra("curso_titulo") ?: ""

        val rvAlumnos = findViewById<RecyclerView>(R.id.rvAlumnos)
        val layoutVacio = findViewById<LinearLayout>(R.id.layoutSinAlumnos)

        findViewById<TextView>(R.id.tvTituloCursoAlumnos).text = cursoTitulo

        rvAlumnos.layoutManager = LinearLayoutManager(this)
        cargarAlumnos(rvAlumnos, layoutVacio)

        // Botón volver
        findViewById<ImageButton>(R.id.btnBackAlumnos).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        val rvAlumnos = findViewById<RecyclerView>(R.id.rvAlumnos)
        val layoutVacio = findViewById<LinearLayout>(R.id.layoutSinAlumnos)
        cargarAlumnos(rvAlumnos, layoutVacio)
    }

    private fun cargarAlumnos(rvAlumnos: RecyclerView, layoutVacio: LinearLayout) {
        val alumnos = db.obtenerAlumnosDelCurso(cursoId)
        findViewById<TextView>(R.id.tvTotalAlumnos).text = "${alumnos.size} alumnos inscritos"

        rvAlumnos.adapter = AlumnoAdapter(
            alumnos,
            cursoId,
            db,
            onAsignarNotaClick = { alumno ->
                startActivity(Intent(this, AsignarNotasActivity::class.java).apply {
                    putExtra("alumno_id", alumno.id)
                    putExtra("curso_id", cursoId)
                    putExtra("alumno_nombre", alumno.nombre)
                    putExtra("curso_titulo", cursoTitulo)
                })
            }
        )

        if (alumnos.isEmpty()) {
            layoutVacio.visibility = View.VISIBLE
            rvAlumnos.visibility = View.GONE
        } else {
            layoutVacio.visibility = View.GONE
            rvAlumnos.visibility = View.VISIBLE
        }
    }
}