package com.example.gestioncursos.adapters

import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.models.Nota

class NotaAdapter(
    private val notas: List<Nota>
) : RecyclerView.Adapter<NotaAdapter.NotaViewHolder>() {

    class NotaViewHolder(val layout: LinearLayout) : RecyclerView.ViewHolder(layout) {
        val tvCurso = TextView(layout.context)
        val tvNota = TextView(layout.context)
        val tvComentario = TextView(layout.context)

        init {
            layout.orientation = LinearLayout.VERTICAL
            layout.setPadding(32, 24, 32, 24)

            tvCurso.textSize = 18f
            tvNota.textSize = 16f
            tvComentario.textSize = 14f

            layout.addView(tvCurso)
            layout.addView(tvNota)
            layout.addView(tvComentario)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotaViewHolder {
        val layout = LinearLayout(parent.context)
        layout.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return NotaViewHolder(layout)
    }

    override fun onBindViewHolder(holder: NotaViewHolder, position: Int) {
        val nota = notas[position]

        holder.tvCurso.text = nota.tituloCurso
        holder.tvNota.text = "Nota: ${nota.nota}/20"
        holder.tvComentario.text =
            if (nota.comentario.isNotEmpty()) "Comentario: ${nota.comentario}" else "Sin comentario"
    }

    override fun getItemCount(): Int = notas.size
}