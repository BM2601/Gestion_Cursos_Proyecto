package com.example.gestioncursos.models

data class Usuario(
    val id: Int = 0,
    val nombre: String,
    val email: String,
    val rol: String,
    val password: String = "",
    val bloqueado: Boolean = false,
    val codigoEstudiante: String = "",
    val telefono: String = ""
)