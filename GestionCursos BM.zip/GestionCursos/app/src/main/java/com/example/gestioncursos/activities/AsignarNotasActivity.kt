// ════════════════════════════════════════════════════════
//
// Se abre desde AlumnosInscritosActivity con un botón "Asignar Nota"
// por cada alumno de la lista (ver instrucciones al final).
// ════════════════════════════════════════════════════════

package com.example.gestioncursos.activities

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton

class AsignarNotasActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var alumnoId = 0
    private var cursoId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asignar_notas)
        db = DatabaseHelper(this)

        alumnoId = intent.getIntExtra("alumno_id", 0)
        cursoId = intent.getIntExtra("curso_id", 0)
        val nombreAlumno = intent.getStringExtra("alumno_nombre") ?: ""
        val tituloCurso = intent.getStringExtra("curso_titulo") ?: ""

        findViewById<TextView>(R.id.tvNombreAlumnoNota).text = nombreAlumno
        findViewById<TextView>(R.id.tvCursoNota).text = tituloCurso
        findViewById<ImageButton>(R.id.btnBackNotas).setOnClickListener { finish() }

        val etNota = findViewById<EditText>(R.id.etValorNota)
        val etComentario = findViewById<EditText>(R.id.etComentarioNota)

        // Si ya existe una nota, precargarla
        val notaExistente = db.obtenerNotaDeAlumnoEnCurso(alumnoId, cursoId)
        if (notaExistente != null) {
            etNota.setText(notaExistente.nota.toString())
            etComentario.setText(notaExistente.comentario)
        }

        findViewById<MaterialButton>(R.id.btnGuardarNota).setOnClickListener {
            val notaTexto = etNota.text.toString().trim()
            val comentario = etComentario.text.toString().trim()

            val notaValor = notaTexto.toDoubleOrNull()
            if (notaValor == null || notaValor < 0 || notaValor > 20) {
                Toast.makeText(this, "Ingresa una nota válida (0 - 20)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            db.asignarNota(alumnoId, cursoId, notaValor, comentario)
            Toast.makeText(this, "Nota guardada correctamente", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}