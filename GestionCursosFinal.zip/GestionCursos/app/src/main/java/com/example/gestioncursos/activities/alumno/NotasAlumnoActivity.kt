package com.example.gestioncursos.activities.alumno

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.adapters.NotaAdapter
import com.example.gestioncursos.database.DatabaseHelper

class NotasAlumnoActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notas_alumno)

        db = DatabaseHelper(this)

        findViewById<ImageButton>(R.id.btnBackNotas).setOnClickListener {
            finish()
        }

        val alumnoId = SessionManager.id(this)

        val notas = db.obtenerNotasDelAlumno(alumnoId)
        val promedio = db.calcularPromedioAlumno(alumnoId)

        findViewById<TextView>(R.id.tvPromedio).text =
            String.format("%.1f", promedio)

        findViewById<TextView>(R.id.tvPromedioGeneral).text =
            String.format("%.1f", promedio)

        findViewById<TextView>(R.id.tvTotalCursos).text =
            notas.size.toString()

        val rvNotas = findViewById<RecyclerView>(R.id.rvNotasAlumno)
        rvNotas.layoutManager = LinearLayoutManager(this)
        rvNotas.adapter = NotaAdapter(notas)
    }
}