package com.example.gestioncursos.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.models.Usuario
import com.google.android.material.chip.Chip

class UsuarioAdapter(
    private var usuarios: List<Usuario>,
    private val onEditClick: (Usuario) -> Unit,
    private val onDeleteClick: (Usuario) -> Unit,
    private val onToggleBloqueoClick: (Usuario) -> Unit,
    private val onCambiarRolClick: (Usuario) -> Unit
) : RecyclerView.Adapter<UsuarioAdapter.UsuarioViewHolder>() {

    inner class UsuarioViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val card: CardView = view.findViewById(R.id.cardUsuario)
        val tvIniciales: TextView = view.findViewById(R.id.tvInicialesUsuario)
        val tvNombre: TextView = view.findViewById(R.id.tvNombreUsuario)
        val tvEmail: TextView = view.findViewById(R.id.tvEmailUsuario)
        val chipRol: Chip = view.findViewById(R.id.chipRolUsuario)
        val chipEstado: Chip = view.findViewById(R.id.chipEstadoUsuario)
        val btnEditar: View = view.findViewById(R.id.btnEditarUsuario)
        val btnEliminar: View = view.findViewById(R.id.btnEliminarUsuario)
        val btnBloquear: View = view.findViewById(R.id.btnBloquearUsuario)
        val btnRol: View = view.findViewById(R.id.btnCambiarRolUsuario)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_usuario, parent, false)
        return UsuarioViewHolder(view)
    }

    override fun onBindViewHolder(holder: UsuarioViewHolder, position: Int) {
        val usuario = usuarios[position]

        holder.tvNombre.text = usuario.nombre
        holder.tvEmail.text = usuario.email
        holder.tvIniciales.text = usuario.nombre.take(2).uppercase()

        holder.chipRol.text = when (usuario.rol) {
            "admin" -> "Admin"
            "profesor" -> "Profesor"
            else -> "Alumno"
        }

        val colorRol = when (usuario.rol) {
            "admin" -> R.color.admin_color
            "profesor" -> R.color.profesor_color
            else -> R.color.alumno_color
        }
        holder.chipRol.setChipBackgroundColorResource(colorRol)
        holder.chipRol.setTextColor(Color.WHITE)

        holder.chipEstado.apply {
            text = if (usuario.bloqueado) "Bloqueado" else "Activo"
            setChipBackgroundColorResource(if (usuario.bloqueado) R.color.danger else R.color.success)
            setTextColor(Color.WHITE)
        }

        holder.btnBloquear.setOnClickListener { onToggleBloqueoClick(usuario) }
        holder.btnEditar.setOnClickListener { onEditClick(usuario) }
        holder.btnEliminar.setOnClickListener { onDeleteClick(usuario) }
        holder.btnRol.setOnClickListener { onCambiarRolClick(usuario) }
    }

    override fun getItemCount() = usuarios.size

    fun actualizarLista(nuevaLista: List<Usuario>) {
        usuarios = nuevaLista
        notifyDataSetChanged()
    }
}