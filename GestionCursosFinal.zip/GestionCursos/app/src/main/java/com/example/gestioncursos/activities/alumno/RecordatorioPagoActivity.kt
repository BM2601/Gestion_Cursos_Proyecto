package com.example.gestioncursos.activities.alumno

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.adapters.PagoAdapter
import com.example.gestioncursos.database.DatabaseHelper
import com.example.gestioncursos.models.Pago



class RecordatorioPagoActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private val pagos = ArrayList<Pago>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recordatorio_pago)

        db = DatabaseHelper(this)

        findViewById<ImageButton>(R.id.btnBackPago).setOnClickListener {
            finish()
        }

        val alumnoId = SessionManager.id(this)

        cargarPagosAlumno(alumnoId)

        val totalPendientes = pagos.count { it.estado.equals("Pendiente", ignoreCase = true) }

        findViewById<TextView>(R.id.tvTotalPendientes).text = totalPendientes.toString()

        findViewById<TextView>(R.id.tvResumenPagos).text =
            "$totalPendientes pagos pendientes"

        val rv = findViewById<RecyclerView>(R.id.rvPagosPendientes)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = PagoAdapter(pagos)
    }

    private fun cargarPagosAlumno(alumnoId: Int) {
        pagos.clear()

        val cursor = db.readableDatabase.rawQuery(
            """
            SELECT id, alumno_id, concepto, monto, fecha_vencimiento, fecha_pago, estado
            FROM pagos
            WHERE alumno_id=?
            ORDER BY estado, fecha_vencimiento
            """.trimIndent(),
            arrayOf(alumnoId.toString())
        )

        while (cursor.moveToNext()) {
            pagos.add(
                Pago(
                    id = cursor.getInt(0),
                    alumnoId = cursor.getInt(1),
                    concepto = cursor.getString(2),
                    monto = cursor.getDouble(3),
                    fechaVencimiento = cursor.getString(4),
                    fechaPago = cursor.getString(5) ?: "",
                    estado = cursor.getString(6)
                )
            )
        }

        cursor.close()
    }
}