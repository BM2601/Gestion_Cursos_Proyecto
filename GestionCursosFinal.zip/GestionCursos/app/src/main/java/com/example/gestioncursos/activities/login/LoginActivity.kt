package com.example.gestioncursos.activities.login

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.admin.AdminDashboardActivity
import com.example.gestioncursos.activities.alumno.AlumnoDashboardActivity
import com.example.gestioncursos.activities.profesor.ProfesorDashboardActivity
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class LoginActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var tilEmail: TextInputLayout
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText

    companion object {
        private const val REQUEST_PERMISOS = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)



        db = DatabaseHelper(this)

        tilEmail    = findViewById(R.id.tilEmail)
        tilPassword = findViewById(R.id.tilPassword)
        etEmail     = findViewById(R.id.etEmail)
        etPassword  = findViewById(R.id.etPassword)

        val tvOlvidePassword = findViewById<TextView>(R.id.tvOlvidePassword)
        val btnLogin         = findViewById<MaterialButton>(R.id.btnLogin)
        val tvIrRegistro     = findViewById<TextView>(R.id.tvIrRegistro)

        tvOlvidePassword.setOnClickListener {
            startActivity(Intent(this, RecuperarPasswordActivity::class.java))
        }

        tvIrRegistro.setOnClickListener {
            startActivity(Intent(this, RegistroActivity::class.java))
        }

        btnLogin.setOnClickListener {
            realizarLogin()
        }

        solicitarPermisosAlInicio()
    }

    private fun solicitarPermisosAlInicio() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val yaSeVio = prefs.getBoolean("aviso_permisos_visto", false)
        if (yaSeVio) return

        AlertDialog.Builder(this)
            .setTitle("Permisos de almacenamiento")
            .setMessage(
                "Esta app necesita acceso a tu almacenamiento para:\n\n" +
                        "📄  Subir materiales PDF a los cursos\n" +
                        "📁  Exportar tu reporte académico\n\n" +
                        "¿Deseas permitir el acceso?"
            )
            .setPositiveButton("Permitir") { _, _ ->
                prefs.edit().putBoolean("aviso_permisos_visto", true).apply()
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ),
                        REQUEST_PERMISOS
                    )
                } else {
                    Toast.makeText(this, "✅ Acceso permitido", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Ahora no") { dialog, _ ->
                prefs.edit().putBoolean("aviso_permisos_visto", true).apply()
                dialog.dismiss()
                Toast.makeText(
                    this,
                    "⚠️ Sin acceso. Algunas funciones estarán limitadas.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .setCancelable(false)
            .show()
    }

    private fun realizarLogin() {
        tilEmail.error    = null
        tilPassword.error = null

        val email    = etEmail.text.toString().trim()
        val password = etPassword.text.toString()

        if (email.isEmpty() && password.isEmpty()) {
            Toast.makeText(this, "Rellene ambos campos", Toast.LENGTH_SHORT).show()
            tilEmail.error    = "Campo requerido"
            tilPassword.error = "Campo requerido"
            return
        }

        if (email.isEmpty()) {
            tilEmail.error = "Ingrese su correo"
            return
        }

        if (password.isEmpty()) {
            tilPassword.error = "Ingrese su contraseña"
            return
        }

        val usuario = db.login(email, password)

        if (usuario != null) {
            if (usuario.bloqueado) {
                Toast.makeText(
                    this,
                    "Usuario bloqueado. Contacte al administrador.",
                    Toast.LENGTH_SHORT
                ).show()
                return
            }

            SessionManager.guardar(
                context = this,
                id      = usuario.id,
                nombre  = usuario.nombre,
                email   = usuario.email,
                rol     = usuario.rol
            )

            val intent = when (usuario.rol.lowercase()) {
                "admin"    -> Intent(this, AdminDashboardActivity::class.java)
                "profesor" -> Intent(this, ProfesorDashboardActivity::class.java)
                else       -> Intent(this, AlumnoDashboardActivity::class.java)
            }

            startActivity(intent)
            finish()

        } else {
            tilPassword.error = "Contraseña incorrecta"
            Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show()
        }
    }
}