package com.example.gestioncursos.models

data class Horario(
    val id: Int = 0,
    val cursoId: Int,
    val nombreCurso: String = "",
    val dia: String,
    val horaInicio: String,
    val horaFin: String,
    val aula: String
)