package com.example.gestioncursos.activities.admin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.admin.GestionPagosAdminActivity
import com.example.gestioncursos.activities.login.LoginActivity
import com.example.gestioncursos.database.DatabaseHelper

class AdminDashboardActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        db = DatabaseHelper(this)

        val prefs = getSharedPreferences("SesionUsuario", MODE_PRIVATE)
        val nombreAdmin = prefs.getString("USUARIO_NOMBRE", "Admin") ?: "Admin"

        findViewById<TextView>(R.id.tvNombreAdmin).text = nombreAdmin

        actualizarEstadisticas()

        findViewById<View>(R.id.cardGestionCursos).setOnClickListener {
            startActivity(Intent(this, GestionCursosAdminActivity::class.java))
        }

        findViewById<View>(R.id.cardGestionUsuarios).setOnClickListener {
            startActivity(Intent(this, GestionUsuariosAdminActivity::class.java))
        }

        findViewById<View>(R.id.cardGestionHorarios).setOnClickListener {
            startActivity(Intent(this, GestionHorariosAdminActivity::class.java))
        }

        findViewById<View>(R.id.cardGestionPagos).setOnClickListener {
            startActivity(Intent(this, GestionPagosAdminActivity::class.java))
        }

        findViewById<View>(R.id.cardCerrarSesion).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Cerrar Sesión")
                .setMessage("¿Deseas salir de la sesión?")
                .setPositiveButton("Sí") { _, _ ->
                    prefs.edit().clear().apply()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finishAffinity()
                }
                .setNegativeButton("No", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        actualizarEstadisticas()
    }

    private fun actualizarEstadisticas() {
        val cursos = db.obtenerTodosCursos()
        val usuarios = db.obtenerTodosUsuarios()

        findViewById<TextView>(R.id.tvTotalCursos).text = cursos.size.toString()
        findViewById<TextView>(R.id.tvCursosActivos).text =
            cursos.count { it.activo }.toString()
        findViewById<TextView>(R.id.tvTotalProfesores).text =
            usuarios.count { it.rol == "profesor" }.toString()
    }
}