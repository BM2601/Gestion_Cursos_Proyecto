package com.example.gestioncursos.activities.login

import android.os.Bundle
import android.text.InputFilter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gestioncursos.R
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton
import java.util.Random

class RegistroActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        db = DatabaseHelper(this)

        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etCodigoEstudiante = findViewById<EditText>(R.id.etCodigoEstudiante)
        val etTelefono = findViewById<EditText>(R.id.etTelefono)
        val etCorreo = findViewById<EditText>(R.id.etCorreo)
        val etPassword = findViewById<EditText>(R.id.etPassword)

        findViewById<ImageButton>(R.id.btnBackRegistro).setOnClickListener {
            finish()
        }

        val codigoGenerado = generarCodigoEstudiante()
        etCodigoEstudiante.setText(codigoGenerado)
        etCodigoEstudiante.isEnabled = false

        etNombre.filters = arrayOf(InputFilter { source, _, _, _, _, _ ->
            if (source.matches(Regex("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]*"))) {
                source
            } else {
                Toast.makeText(this, "Solo se aceptan letras en el nombre", Toast.LENGTH_SHORT).show()
                ""
            }
        })

        etTelefono.filters = arrayOf(InputFilter { source, _, _, _, _, _ ->
            if (source.matches(Regex("[0-9]*"))) {
                source
            } else {
                Toast.makeText(this, "Solo se aceptan números en el teléfono", Toast.LENGTH_SHORT).show()
                ""
            }
        })

        findViewById<MaterialButton>(R.id.btnRegistrarUsuario).setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val codigoEstudiante = etCodigoEstudiante.text.toString().trim()
            val telefono = etTelefono.text.toString().trim()
            val correo = etCorreo.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (nombre.isEmpty()) {
                etNombre.error = "Falta rellenar este campo"
                return@setOnClickListener
            }

            if (codigoEstudiante.isEmpty()) {
                etCodigoEstudiante.error = "Falta rellenar este campo"
                return@setOnClickListener
            }

            if (telefono.isEmpty()) {
                etTelefono.error = "Falta rellenar este campo"
                return@setOnClickListener
            }

            if (correo.isEmpty()) {
                etCorreo.error = "Falta rellenar este campo"
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                etPassword.error = "Falta rellenar este campo"
                return@setOnClickListener
            }

            if (db.buscarUsuarioPorEmail(correo) != null) {
                Toast.makeText(this, "Ese correo ya existe", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val r = db.registrarUsuario(
                nombre,
                correo,
                password,
                "alumno",
                codigoEstudiante,
                telefono
            )

            Toast.makeText(
                this,
                if (r > 0) "Usuario registrado" else "Error al registrar",
                Toast.LENGTH_SHORT
            ).show()

            if (r > 0) finish()
        }
    }

    private fun generarCodigoEstudiante(): String {
        val numero = Random().nextInt(90000) + 10000
        return "EST$numero"
    }
}