package com.example.gestioncursos.models

data class Nota(
    val id: Int = 0,
    val alumnoId: Int,
    val cursoId: Int,
    val tituloCurso: String = "",
    val nota: Double,
    val comentario: String = ""
)
