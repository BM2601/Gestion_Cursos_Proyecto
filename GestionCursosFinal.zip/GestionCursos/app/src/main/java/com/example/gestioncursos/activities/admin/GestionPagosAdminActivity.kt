package com.example.gestioncursos.activities.admin

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.adapters.PagoAdapter
import com.example.gestioncursos.database.DatabaseHelper
import com.example.gestioncursos.models.Pago
import com.google.android.material.button.MaterialButton

class GestionPagosAdminActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var rv: RecyclerView
    private val pagos = ArrayList<Pago>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gestion_pagos_admin)

        db = DatabaseHelper(this)

        findViewById<ImageButton>(R.id.btnBackPagos).setOnClickListener {
            finish()
        }

        rv = findViewById(R.id.rvPagosAdmin)
        rv.layoutManager = LinearLayoutManager(this)

        findViewById<MaterialButton>(R.id.btnRegistrarPago).setOnClickListener {
            registrarPago()
        }

        cargarPagos()
    }

    private fun registrarPago() {
        val alumnoId = findViewById<EditText>(R.id.etAlumnoIdPago).text.toString().toIntOrNull()
        val concepto = findViewById<EditText>(R.id.etConceptoPago).text.toString().trim()
        val monto = findViewById<EditText>(R.id.etMontoPago).text.toString().toDoubleOrNull()
        val fecha = findViewById<EditText>(R.id.etFechaVencimientoPago).text.toString().trim()

        if (alumnoId == null || alumnoId <= 0) {
            Toast.makeText(this, "Ingresa un ID de alumno válido", Toast.LENGTH_SHORT).show()
            return
        }

        if (concepto.isEmpty()) {
            Toast.makeText(this, "Ingresa el concepto del pago", Toast.LENGTH_SHORT).show()
            return
        }

        if (monto == null || monto <= 0) {
            Toast.makeText(this, "Ingresa un monto válido", Toast.LENGTH_SHORT).show()
            return
        }

        if (fecha.isEmpty()) {
            Toast.makeText(this, "Ingresa la fecha de vencimiento", Toast.LENGTH_SHORT).show()
            return
        }

        db.registrarPago(alumnoId, concepto, monto, fecha)
        Toast.makeText(this, "Deuda registrada como pendiente", Toast.LENGTH_SHORT).show()

        limpiarCampos()
        cargarPagos()
    }

    private fun cargarPagos() {
        pagos.clear()

        val cursor = db.readableDatabase.rawQuery(
            """
            SELECT id, alumno_id, concepto, monto, fecha_vencimiento, fecha_pago, estado
            FROM pagos
            ORDER BY estado, fecha_vencimiento
            """.trimIndent(),
            null
        )

        while (cursor.moveToNext()) {
            pagos.add(
                Pago(
                    id = cursor.getInt(0),
                    alumnoId = cursor.getInt(1),
                    concepto = cursor.getString(2),
                    monto = cursor.getDouble(3),
                    fechaVencimiento = cursor.getString(4),
                    fechaPago = cursor.getString(5) ?: "",
                    estado = cursor.getString(6)
                )
            )
        }

        cursor.close()

        rv.adapter = PagoAdapter(
            pagos = pagos,
            showAdminButton = true,
            onMarcarPagadoClick = { pago ->
                db.marcarPagoComoPagado(pago.id)
                Toast.makeText(this, "Pago marcado como pagado", Toast.LENGTH_SHORT).show()
                cargarPagos()
            }
        )
    }

    private fun limpiarCampos() {
        findViewById<EditText>(R.id.etAlumnoIdPago).text.clear()
        findViewById<EditText>(R.id.etConceptoPago).text.clear()
        findViewById<EditText>(R.id.etMontoPago).text.clear()
        findViewById<EditText>(R.id.etFechaVencimientoPago).text.clear()
    }
}