package com.example.gestioncursos.activities.alumno

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.activities.login.LoginActivity
import com.example.gestioncursos.adapters.CursoAdapter
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

class AlumnoDashboardActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var rvCursos: RecyclerView
    private var alumnoId = 0
    private var nombreAlumno = "Alumno"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alumno_dashboard)

        db = DatabaseHelper(this)

        // ✅ Lee siempre de SessionManager
        alumnoId = SessionManager.id(this)
        nombreAlumno = SessionManager.nombre(this)

        findViewById<TextView>(R.id.tvBienvenida).text = "¡Hola, $nombreAlumno!"

        rvCursos = findViewById(R.id.rvMisCursos)
        rvCursos.layoutManager = LinearLayoutManager(this)

        findViewById<ExtendedFloatingActionButton>(R.id.fabBuscarCursos).setOnClickListener {
            startActivity(Intent(this, BuscarCursosActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnMisHorariosAlumno).setOnClickListener {
            startActivity(Intent(this, HorariosAlumnoActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnMisTareasAlumno).setOnClickListener {
            startActivity(Intent(this, TareasAlumnoActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnNotasAlumno).setOnClickListener {
            startActivity(Intent(this, NotasAlumnoActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnRecordatorioPago).setOnClickListener {
            startActivity(Intent(this, RecordatorioPagoActivity::class.java))
        }

        findViewById<ImageButton>(R.id.btnPerfilAlumno).setOnClickListener {
            startActivity(Intent(this, PerfilAlumnoActivity::class.java))
        }

        findViewById<ImageButton>(R.id.btnLogoutAlumno).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Cerrar Sesión")
                .setMessage("¿Deseas salir de la sesión?")
                .setPositiveButton("Sí") { _, _ ->
                    SessionManager.cerrar(this)
                }
                .setNegativeButton("No", null)
                .show()
        }

        cargarMisCursos()
    }

    override fun onResume() {
        super.onResume()
        cargarMisCursos()
    }

    private fun cargarMisCursos() {
        val cursos = db.obtenerCursosDelAlumno(alumnoId)

        rvCursos.adapter = CursoAdapter(
            cursos,
            onItemClick = { curso ->
                startActivity(
                    Intent(this, DetalleCursoActivity::class.java).apply {
                        putExtra("curso_id", curso.id)
                    }
                )
            }
        )

        findViewById<TextView>(R.id.tvCursosCount).text = cursos.size.toString()

        val proxima = db.obtenerProximaClase(alumnoId)
        findViewById<TextView>(R.id.tvProximaClase).text =
            if (proxima != null) "${proxima.dia}\n${proxima.horaInicio}" else "--"
    }
}