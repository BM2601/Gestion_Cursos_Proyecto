package com.example.gestioncursos.activities.alumno

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.adapters.TareaAdapter
import com.example.gestioncursos.database.DatabaseHelper

class TareasAlumnoActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var rvTareas: RecyclerView
    private lateinit var tvTotal: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tareas_alumno)

        db = DatabaseHelper(this)

        findViewById<ImageButton>(R.id.btnBackTareasAlumno).setOnClickListener { finish() }

        tvTotal = findViewById(R.id.tvTotalTareasAlumno)
        rvTareas = findViewById(R.id.rvTareasAlumno)
        rvTareas.layoutManager = LinearLayoutManager(this)

        cargarTareas()
    }

    private fun cargarTareas() {
        // ✅ SessionManager en vez de SesionUsuario
        val alumnoId = SessionManager.id(this)
        val tareas = db.obtenerTareasAlumno(alumnoId)

        tvTotal.text = "${tareas.size} tareas registradas"

        rvTareas.adapter = TareaAdapter(
            lista = tareas,
            onCompletarClick = { tarea ->
                db.marcarTareaCompletada(tarea.id)
                Toast.makeText(this, "Tarea completada", Toast.LENGTH_SHORT).show()
                cargarTareas()
            },
            onEditarClick = { },
            onEliminarClick = { },
            showEditarEliminar = false
        )
    }
}