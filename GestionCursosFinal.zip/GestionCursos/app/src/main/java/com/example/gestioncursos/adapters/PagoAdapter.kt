package com.example.gestioncursos.adapters

import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.models.Pago

class PagoAdapter(
    private val pagos: List<Pago>,
    private val showAdminButton: Boolean = false,
    private val onMarcarPagadoClick: ((Pago) -> Unit)? = null
) : RecyclerView.Adapter<PagoAdapter.PagoViewHolder>() {

    class PagoViewHolder(val layout: LinearLayout) : RecyclerView.ViewHolder(layout) {
        val tvConcepto = TextView(layout.context)
        val tvMonto = TextView(layout.context)
        val tvVencimiento = TextView(layout.context)
        val tvEstado = TextView(layout.context)
        val btnPagado = Button(layout.context)

        init {
            layout.orientation = LinearLayout.VERTICAL
            layout.setPadding(32, 24, 32, 24)

            tvConcepto.textSize = 18f
            tvMonto.textSize = 16f
            tvVencimiento.textSize = 14f
            tvEstado.textSize = 14f

            btnPagado.text = "Marcar como pagado"

            layout.addView(tvConcepto)
            layout.addView(tvMonto)
            layout.addView(tvVencimiento)
            layout.addView(tvEstado)
            layout.addView(btnPagado)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PagoViewHolder {
        val layout = LinearLayout(parent.context)
        layout.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return PagoViewHolder(layout)
    }

    override fun onBindViewHolder(holder: PagoViewHolder, position: Int) {
        val pago = pagos[position]

        holder.tvConcepto.text = "Alumno ID: ${pago.alumnoId} - ${pago.concepto}"
        holder.tvMonto.text = "Monto: S/ ${pago.monto}"
        holder.tvVencimiento.text = "Vence: ${pago.fechaVencimiento}"
        holder.tvEstado.text = "Estado: ${pago.estado}"

        holder.btnPagado.visibility =
            if (showAdminButton && pago.estado != "Pagado") View.VISIBLE else View.GONE

        holder.btnPagado.setOnClickListener {
            onMarcarPagadoClick?.invoke(pago)
        }
    }

    override fun getItemCount(): Int = pagos.size
}