package com.example.gestioncursos.activities

import android.os.Bundle
import android.os.Environment
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.example.gestioncursos.R
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton
import java.io.File
import java.io.FileWriter

class PerfilAlumnoActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var alumnoId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil_alumno)
        db = DatabaseHelper(this)

        alumnoId = intent.getIntExtra("usuario_id", 0)
        val usuario = db.obtenerUsuarioPorId(alumnoId) ?: return

        findViewById<ImageButton>(R.id.btnBackPerfil).setOnClickListener { finish() }

        val etNombre = findViewById<EditText>(R.id.etNombrePerfil)
        val etTelefono = findViewById<EditText>(R.id.etTelefonoPerfil)
        val tvEmail = findViewById<TextView>(R.id.tvEmailPerfil)
        val tvCodigo = findViewById<TextView>(R.id.tvCodigoPerfil)
        val tvPromedio = findViewById<TextView>(R.id.tvPromedioPerfil)
        val tvCursosInscritos = findViewById<TextView>(R.id.tvCursosInscritosPerfil)

        etNombre.setText(usuario.nombre)
        etTelefono.setText(usuario.telefono)
        tvEmail.text = usuario.email
        tvCodigo.text = if (usuario.codigoEstudiante.isNotEmpty()) usuario.codigoEstudiante else "Sin asignar"

        val cursos = db.obtenerCursosDelAlumno(alumnoId)
        val promedio = db.calcularPromedioAlumno(alumnoId)
        tvCursosInscritos.text = "${cursos.size} cursos inscritos"
        tvPromedio.text = if (promedio > 0) String.format("%.1f", promedio) else "Sin notas aún"

        findViewById<MaterialButton>(R.id.btnGuardarPerfil).setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val telefono = etTelefono.text.toString().trim()
            if (nombre.isEmpty()) {
                Toast.makeText(this, "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            db.actualizarPerfilAlumno(alumnoId, nombre, telefono)
            Toast.makeText(this, "Datos actualizados correctamente", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.btnDescargarDatos).setOnClickListener {
            generarReporteDatos(usuario.nombre, usuario.email, usuario.codigoEstudiante, usuario.telefono)
        }

    }

    private fun generarReporteDatos(nombre: String, email: String, codigo: String, telefono: String) {
        try {
            val cursos = db.obtenerCursosDelAlumno(alumnoId)
            val notas = db.obtenerNotasDelAlumno(alumnoId)
            val horarios = db.obtenerHorariosAlumno(alumnoId)
            val promedio = db.calcularPromedioAlumno(alumnoId)

            val contenido = buildString {
                appendLine("═══════════════════════════════════════")
                appendLine("   REPORTE DE DATOS PERSONALES")
                appendLine("   EduCursos")
                appendLine("═══════════════════════════════════════")
                appendLine()
                appendLine("DATOS PERSONALES")
                appendLine("-----------------")
                appendLine("Nombre: $nombre")
                appendLine("Correo: $email")
                appendLine("Código de estudiante: ${codigo.ifEmpty { "Sin asignar" }}")
                appendLine("Teléfono: ${telefono.ifEmpty { "Sin registrar" }}")
                appendLine()
                appendLine("CURSOS INSCRITOS (${cursos.size})")
                appendLine("-----------------")
                if (cursos.isEmpty()) {
                    appendLine("Sin cursos inscritos")
                } else {
                    cursos.forEach { curso ->
                        appendLine("• ${curso.titulo} — Prof. ${curso.nombreProfesor}")
                    }
                }
                appendLine()
                appendLine("NOTAS")
                appendLine("-----------------")
                if (notas.isEmpty()) {
                    appendLine("Sin notas registradas")
                } else {
                    notas.forEach { nota ->
                        appendLine("• ${nota.tituloCurso}: ${nota.nota}/20")
                        if (nota.comentario.isNotEmpty()) appendLine("  Comentario: ${nota.comentario}")
                    }
                }
                appendLine()
                appendLine("PROMEDIO GENERAL: ${if (promedio > 0) String.format("%.2f", promedio) else "N/A"}")
                appendLine()
                appendLine("HORARIO")
                appendLine("-----------------")
                if (horarios.isEmpty()) {
                    appendLine("Sin horario asignado")
                } else {
                    horarios.forEach { h ->
                        appendLine("• ${h.dia}: ${h.horaInicio} - ${h.horaFin} | ${h.nombreCurso} | Aula ${h.aula}")
                    }
                }
                appendLine()
                appendLine("═══════════════════════════════════════")
                appendLine("Generado el ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}")
            }

            val carpeta = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "")
            if (!carpeta.exists()) carpeta.mkdirs()
            val archivo = File(carpeta, "MisDatos_${nombre.replace(" ", "_")}.txt")

            FileWriter(archivo).use { it.write(contenido) }

            Toast.makeText(this, "Archivo guardado: ${archivo.name}", Toast.LENGTH_LONG).show()

            // Abrir/compartir el archivo generado
            val uri = FileProvider.getUriForFile(
                this, "${packageName}.fileprovider", archivo
            )
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "text/plain")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Archivo guardado en Documents", Toast.LENGTH_SHORT).show()
            }

        } catch (e: Exception) {
            Toast.makeText(this, "Error al generar el archivo: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}