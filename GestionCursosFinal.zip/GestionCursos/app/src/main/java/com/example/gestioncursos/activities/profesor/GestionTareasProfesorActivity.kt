package com.example.gestioncursos.activities.profesor

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.adapters.TareaAdapter
import com.example.gestioncursos.database.DatabaseHelper
import com.google.android.material.button.MaterialButton

class GestionTareasProfesorActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var rv: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gestion_tareas_profesor)

        db = DatabaseHelper(this)

        rv = findViewById(R.id.rvTareasProfesor)
        rv.layoutManager = LinearLayoutManager(this)

        findViewById<ImageButton>(R.id.btnBackTareasProfesor).setOnClickListener {
            finish()
        }

        findViewById<MaterialButton>(R.id.btnNuevaTarea).setOnClickListener {
            startActivity(Intent(this, CrearEditarTareaActivity::class.java))
        }

        cargar()
    }

    override fun onResume() {
        super.onResume()
        cargar()
    }

    private fun cargar() {
        rv.adapter = TareaAdapter(
            db.listarTareas(),
            onCompletarClick = { tarea ->
                db.marcarTareaCompletada(tarea.id)
                cargar()
            },
            onEditarClick = { tarea ->
                val intent = Intent(this, CrearEditarTareaActivity::class.java)
                intent.putExtra("id", tarea.id)
                intent.putExtra("titulo", tarea.titulo)
                intent.putExtra("descripcion", tarea.descripcion)
                intent.putExtra("curso", tarea.curso)
                intent.putExtra("fecha", tarea.fechaLimite)
                intent.putExtra("estado", tarea.estado)
                startActivity(intent)
            },
            onEliminarClick = { tarea ->
                db.eliminarTarea(tarea.id)
                cargar()
            }
        )
    }
}