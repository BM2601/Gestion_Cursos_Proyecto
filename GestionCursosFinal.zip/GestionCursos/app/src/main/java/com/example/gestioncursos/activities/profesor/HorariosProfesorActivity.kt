package com.example.gestioncursos.activities.profesor

import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gestioncursos.R
import com.example.gestioncursos.activities.utils.SessionManager
import com.example.gestioncursos.adapters.HorarioAdapter
import com.example.gestioncursos.database.DatabaseHelper

class HorariosProfesorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_horarios_profesor)

        findViewById<ImageButton>(R.id.btnBackProfesorHorario).setOnClickListener { finish() }

        val recycler = findViewById<RecyclerView>(R.id.recyclerHorariosProfesor)
        recycler.layoutManager = LinearLayoutManager(this)

        // ✅ SessionManager en vez de SesionUsuario
        val profesorId = SessionManager.id(this)
        val db = DatabaseHelper(this)
        val horarios = db.obtenerHorariosProfesor(profesorId)

        if (horarios.isEmpty()) {
            Toast.makeText(this, "No tienes horarios asignados", Toast.LENGTH_SHORT).show()
        }

        recycler.adapter = HorarioAdapter(horarios)
    }
}